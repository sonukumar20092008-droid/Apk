# LabDesk (offline lab app)

Open this folder in Android Studio (File > Open), wait for Gradle sync, then
Build > Build Bundle(s) / APK(s) > Build APK(s).

- Language: Java, minSdk 24, targetSdk 34, no internet permission, all data in local SQLite.
- Package: com.labdesk.app

Screens: Dashboard (counts + chart), Bookings, Reports, Settings, New Booking, drawer menu
(tests, packages, referrals, staff, expenses, wallet, inventory, patients, summary report ...).

Hide price list on patient report:
  Settings > "Hide price list on patient report" (ON/OFF).
  When sharing a report PDF you also get a checkbox to override it for that one report.
