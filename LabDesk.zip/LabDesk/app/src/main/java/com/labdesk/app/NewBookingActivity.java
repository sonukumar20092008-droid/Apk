package com.labdesk.app;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class NewBookingActivity extends AppCompatActivity {

    private final Calendar cal = Calendar.getInstance();
    private final List<String[]> selected = new ArrayList<>(); // name, price, type
    private List<Item> doctors = new ArrayList<>();

    private Spinner spDept, spDoc, spTitle, spUnit, spGender, spGroup, spStaff;
    private ArrayAdapter<String> docAdapter;
    private EditText etPct, etAmt, etName, etAge, etMobile, etInfo, etDesc, etDiscount, etPaid;
    private TextView tvDate, tvTime, tvTotal, tvDue;
    private SwitchCompat swImportant;
    private LinearLayout selectedBox;

    private static final String[] TITLES = {"Mr.", "Mrs.", "Ms.", "Miss", "Master", "Baby", "Dr."};
    private static final String[] GENDERS = {"Male", "Female", "Other"};
    private static final String[] UNITS = {"Years", "Months", "Days"};
    private static final String[] GROUPS = {"Infant - under 1 year", "Child - under 18 years", "Adult - 18+ years", "Senior - 60+ years"};

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        U.init(this);
        U.style(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(U.bg());

        // top bar
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(U.dp(this, 12), U.dp(this, 8), U.dp(this, 14), U.dp(this, 8));
        FrameLayout back = U.circleBtn(this, R.drawable.ic_back);
        back.setOnClickListener(v -> finish());
        top.addView(back, U.lpm(this, 44, 44, 0, 0, 12, 0));
        LinearLayout tt = new LinearLayout(this);
        tt.setOrientation(LinearLayout.VERTICAL);
        tt.addView(U.tv(this, "New Booking", 20, U.text(), true));
        tt.addView(U.tv(this, "Fast, secure, and accurate pathology test booking", 12, U.sub(), false));
        top.addView(tt, U.lpw(1));
        root.addView(top, U.lp(-1, -2));

        // form
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(U.dp(this, 16), U.dp(this, 4), U.dp(this, 16), U.dp(this, 16));
        sv.addView(f);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        Db db = Db.get(this);

        // department
        List<String> depts = new ArrayList<>();
        for (Item i : db.items("department")) depts.add(i.name);
        if (depts.isEmpty()) depts.add("Pathology");
        spDept = spinner(f, "Department*", depts);

        // referred by
        spDoc = spinner(f, "Referred By / Doctor", new ArrayList<String>());
        docAdapter = (ArrayAdapter<String>) spDoc.getAdapter();
        loadDoctors();
        TextView addDoc = U.tv(this, "+  Add Referred By / Doctor", 13, Color.WHITE, true);
        addDoc.setBackground(U.rect(this, U.PRIMARY, 12));
        addDoc.setPadding(U.dp(this, 16), U.dp(this, 10), U.dp(this, 16), U.dp(this, 10));
        addDoc.setOnClickListener(v -> addDoctor());
        LinearLayout ar = new LinearLayout(this);
        ar.setGravity(Gravity.END);
        ar.addView(addDoc);
        f.addView(ar, U.lpm(this, -1, -2, 0, 0, 0, 8));

        // commission
        LinearLayout cr = new LinearLayout(this);
        etPct = U.et(this, "Commission (%)", U.T_NUM);
        etAmt = U.et(this, "Commission Amount", U.T_NUM);
        cr.addView(etPct, U.lpmw(this, 1, 0, 0, 4, 0));
        cr.addView(etAmt, U.lpmw(this, 1, 4, 0, 0, 0));
        f.addView(cr, U.lpm(this, -1, -2, 0, 0, 0, 8));
        spDoc.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (pos > 0 && pos - 1 < doctors.size()) etPct.setText(trim(doctors.get(pos - 1).amount));
                else etPct.setText("0");
            }
            public void onNothingSelected(AdapterView<?> p) {}
        });

        // date / time
        LinearLayout dr = new LinearLayout(this);
        tvDate = pickerCard(dr, "Booking Date*", true);
        tvTime = pickerCard(dr, "Booking Time*", false);
        f.addView(dr, U.lpm(this, -1, -2, 0, 0, 0, 8));
        showDateTime();

        // title + name
        LinearLayout nr = new LinearLayout(this);
        spTitle = bare(Arrays.asList(TITLES));
        spTitle.setBackground(U.rect(this, U.card(), 14, U.line()));
        nr.addView(spTitle, U.lpm(this, U.dp(this, 100), U.dp(this, 52), 0, 0, 6, 0));
        etName = U.et(this, "Patient Name*", U.T_TEXT);
        nr.addView(etName, U.lpw(1));
        f.addView(nr, U.lpm(this, -1, -2, 0, 0, 0, 8));
        spTitle.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                String t = TITLES[pos];
                if (t.equals("Mr.") || t.equals("Master")) spGender.setSelection(0);
                else if (t.equals("Mrs.") || t.equals("Ms.") || t.equals("Miss")) spGender.setSelection(1);
            }
            public void onNothingSelected(AdapterView<?> p) {}
        });

        // age + unit
        LinearLayout ag = new LinearLayout(this);
        etAge = U.et(this, "Age*", InputType.TYPE_CLASS_NUMBER);
        ag.addView(etAge, U.lpmw(this, 1, 0, 0, 4, 0));
        LinearLayout unitBox = labeled("Age Unit*", Arrays.asList(UNITS));
        spUnit = (Spinner) unitBox.getChildAt(1);
        ag.addView(unitBox, U.lpmw(this, 1, 4, 0, 0, 0));
        f.addView(ag, U.lpm(this, -1, -2, 0, 0, 0, 8));

        // gender + age group
        LinearLayout gr = new LinearLayout(this);
        LinearLayout gBox = labeled("Gender", Arrays.asList(GENDERS));
        spGender = (Spinner) gBox.getChildAt(1);
        gr.addView(gBox, U.lpmw(this, 1, 0, 0, 4, 0));
        LinearLayout agBox = labeled("Age Group", Arrays.asList(GROUPS));
        spGroup = (Spinner) agBox.getChildAt(1);
        spGroup.setSelection(2);
        gr.addView(agBox, U.lpmw(this, 1, 4, 0, 0, 0));
        f.addView(gr, U.lpm(this, -1, -2, 0, 0, 0, 8));

        TextWatcher groupWatcher = new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable s) { autoGroup(); }
        };
        etAge.addTextChangedListener(groupWatcher);
        spUnit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { autoGroup(); }
            public void onNothingSelected(AdapterView<?> p) {}
        });

        etMobile = U.et(this, "Mobile Number", InputType.TYPE_CLASS_PHONE);
        f.addView(etMobile, U.lpm(this, -1, -2, 0, 0, 0, 8));

        etInfo = U.et(this, "Address, email or other info", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        f.addView(expandable("Additional Info", etInfo), U.lpm(this, -1, -2, 0, 0, 0, 8));
        etDesc = U.et(this, "Description / clinical notes", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        f.addView(expandable("Description", etDesc), U.lpm(this, -1, -2, 0, 0, 0, 8));

        // sample collected by
        List<String> staff = new ArrayList<>();
        for (Item i : db.items("staff")) staff.add(i.name);
        if (staff.isEmpty()) staff.add("Self");
        spStaff = spinner(f, "Sample Collected By*", staff);

        // important
        LinearLayout imp = U.card(this);
        imp.setOrientation(LinearLayout.HORIZONTAL);
        imp.setGravity(Gravity.CENTER_VERTICAL);
        imp.addView(U.icon(this, R.drawable.ic_star, U.AMBER, 22), U.lpm(this, 22, 22, 0, 0, 12, 0));
        LinearLayout it = new LinearLayout(this);
        it.setOrientation(LinearLayout.VERTICAL);
        it.addView(U.tv(this, "Mark as important", 16, U.text(), true));
        it.addView(U.tv(this, "Listed first and highlighted until its report is made.", 12, U.sub(), false));
        imp.addView(it, U.lpw(1));
        swImportant = new SwitchCompat(this);
        imp.addView(swImportant);
        f.addView(imp, U.lpm(this, -1, -2, 0, 0, 0, 10));

        // selected tests + totals
        selectedBox = U.card(this);
        f.addView(selectedBox, U.lpm(this, -1, -2, 0, 0, 0, 10));

        LinearLayout pr = new LinearLayout(this);
        etDiscount = U.et(this, "Discount", U.T_NUM);
        etPaid = U.et(this, "Paid now", U.T_NUM);
        pr.addView(etDiscount, U.lpmw(this, 1, 0, 0, 4, 0));
        pr.addView(etPaid, U.lpmw(this, 1, 4, 0, 0, 0));
        f.addView(pr, U.lpm(this, -1, -2, 0, 0, 0, 0));
        TextWatcher money = new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable s) { updateTotals(); }
        };
        etDiscount.addTextChangedListener(money);
        etPaid.addTextChangedListener(money);
        renderSelected();

        // bottom buttons
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(U.dp(this, 16), U.dp(this, 8), U.dp(this, 16), U.dp(this, 14));
        LinearLayout pick = new LinearLayout(this);
        TextView pkg = pickBtn("Select Package  ▾");
        TextView tst = pickBtn("Select Test  ▾");
        pkg.setOnClickListener(v -> pickItems("package"));
        tst.setOnClickListener(v -> pickItems("test"));
        pick.addView(pkg, U.lpmw(this, 1, 0, 0, 6, 0));
        pick.addView(tst, U.lpmw(this, 1, 6, 0, 0, 0));
        bottom.addView(pick, U.lpm(this, -1, -2, 0, 0, 0, 10));
        TextView submit = U.tv(this, "Submit", 17, Color.WHITE, true);
        submit.setGravity(Gravity.CENTER);
        submit.setBackground(U.rect(this, U.PRIMARY, 16));
        submit.setOnClickListener(v -> submit());
        bottom.addView(submit, U.lp(-1, U.dp(this, 54)));
        root.addView(bottom, U.lp(-1, -2));

        setContentView(root);
    }

    // ------------------------------------------------------------------ small builders

    private Spinner bare(List<String> opts) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,
                new ArrayList<String>(opts)) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                if (v instanceof TextView) ((TextView) v).setTextColor(U.text());
                return v;
            }
        };
        s.setAdapter(ad);
        return s;
    }

    /** Card with a small label above a spinner. Child 0 = label, child 1 = spinner. */
    private LinearLayout labeled(String label, List<String> opts) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(U.rect(this, U.card(), 14, U.line()));
        c.setPadding(U.dp(this, 12), U.dp(this, 6), U.dp(this, 6), U.dp(this, 2));
        c.addView(U.tv(this, label, 11, U.sub(), false));
        c.addView(bare(opts), U.lp(-1, U.dp(this, 40)));
        return c;
    }

    private Spinner spinner(LinearLayout parent, String label, List<String> opts) {
        LinearLayout c = labeled(label, opts);
        parent.addView(c, U.lpm(this, -1, -2, 0, 0, 0, 8));
        return (Spinner) c.getChildAt(1);
    }

    private TextView pickBtn(String t) {
        TextView v = U.tv(this, t, 15, Color.WHITE, true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(U.rect(this, U.PRIMARY, 28));
        v.setPadding(0, U.dp(this, 14), 0, U.dp(this, 14));
        return v;
    }

    private TextView pickerCard(LinearLayout parent, String label, final boolean date) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(U.rect(this, U.card(), 14, U.line()));
        c.setPadding(U.dp(this, 14), U.dp(this, 8), U.dp(this, 10), U.dp(this, 10));
        c.addView(U.tv(this, label, 11, U.sub(), false));
        TextView v = U.tv(this, "", 16, U.chipText(), true);
        c.addView(v);
        c.setOnClickListener(x -> {
            if (date) {
                new DatePickerDialog(this, (dp, y, m, d) -> {
                    cal.set(y, m, d);
                    showDateTime();
                }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
            } else {
                new TimePickerDialog(this, (tp, h, min) -> {
                    cal.set(Calendar.HOUR_OF_DAY, h);
                    cal.set(Calendar.MINUTE, min);
                    showDateTime();
                }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show();
            }
        });
        boolean first = date;
        parent.addView(c, first ? U.lpmw(this, 1, 0, 0, 4, 0) : U.lpmw(this, 1, 4, 0, 0, 0));
        return v;
    }

    private void showDateTime() {
        tvDate.setText(new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(cal.getTime()));
        tvTime.setText(new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(cal.getTime()));
    }

    private View expandable(String title, final EditText inner) {
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(U.rect(this, U.card(), 14, U.line()));
        LinearLayout h = new LinearLayout(this);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(U.dp(this, 14), U.dp(this, 14), U.dp(this, 10), U.dp(this, 14));
        h.addView(U.tv(this, title, 16, U.text(), false), U.lpw(1));
        h.addView(U.icon(this, R.drawable.ic_expand, U.text(), 24));
        box.addView(h);
        inner.setVisibility(View.GONE);
        box.addView(inner, U.lpm(this, -1, -2, 10, 0, 10, 10));
        h.setOnClickListener(v -> inner.setVisibility(inner.getVisibility() == View.GONE ? View.VISIBLE : View.GONE));
        return box;
    }

    // ------------------------------------------------------------------ logic

    private static String trim(double v) {
        return v == Math.floor(v) ? String.valueOf((long) v) : String.valueOf(v);
    }

    private void loadDoctors() {
        doctors = Db.get(this).items("doctor");
        docAdapter.clear();
        docAdapter.add("Self (No Referral)");
        for (Item d : doctors) docAdapter.add(d.name);
        docAdapter.notifyDataSetChanged();
    }

    private void addDoctor() {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(U.dp(this, 20), U.dp(this, 8), U.dp(this, 20), 0);
        final EditText n = new EditText(this);
        n.setHint("Doctor / referrer name");
        n.setInputType(U.T_TEXT);
        final EditText p = new EditText(this);
        p.setHint("Phone");
        p.setInputType(InputType.TYPE_CLASS_PHONE);
        final EditText c = new EditText(this);
        c.setHint("Default commission (%)");
        c.setInputType(U.T_NUM);
        f.addView(n);
        f.addView(p);
        f.addView(c);
        new AlertDialog.Builder(this).setTitle("Add Referred By / Doctor").setView(f)
                .setPositiveButton("Save", (d, w) -> {
                    String name = n.getText().toString().trim();
                    if (name.isEmpty()) {
                        U.toast(this, "Name is required");
                        return;
                    }
                    Item it = new Item();
                    it.type = "doctor";
                    it.name = name;
                    it.extra = p.getText().toString().trim();
                    it.amount = U.num(c.getText().toString());
                    Db.get(this).saveItem(it);
                    loadDoctors();
                    for (int i = 0; i < doctors.size(); i++) {
                        if (doctors.get(i).id == it.id) spDoc.setSelection(i + 1);
                    }
                })
                .setNegativeButton("Cancel", null).show();
    }

    private void autoGroup() {
        int age = (int) U.num(etAge.getText().toString());
        String unit = UNITS[spUnit.getSelectedItemPosition()];
        double years = unit.equals("Years") ? age : unit.equals("Months") ? age / 12.0 : 0;
        int g;
        if (etAge.getText().length() == 0) g = 2;
        else if (years < 1) g = 0;
        else if (years < 18) g = 1;
        else if (years < 60) g = 2;
        else g = 3;
        spGroup.setSelection(g);
    }

    private void pickItems(final String type) {
        final List<Item> all = Db.get(this).items(type);
        if (all.isEmpty()) {
            U.toast(this, "No " + type + "s yet. Add them from the menu: Lab Test & Packages");
            return;
        }
        List<String> labels = Actions.labels(all);
        final boolean[] checked = new boolean[all.size()];
        for (int i = 0; i < all.size(); i++) {
            for (String[] s : selected) {
                if (s[2].equals(type) && s[0].equalsIgnoreCase(all.get(i).name)) checked[i] = true;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle("package".equals(type) ? "Select Package" : "Select Test")
                .setMultiChoiceItems(labels.toArray(new String[0]), checked, (d, which, on) -> checked[which] = on)
                .setPositiveButton("Done", (d, w) -> {
                    for (int i = selected.size() - 1; i >= 0; i--) if (selected.get(i)[2].equals(type)) selected.remove(i);
                    for (int i = 0; i < all.size(); i++) {
                        if (checked[i]) selected.add(new String[]{all.get(i).name, trim(all.get(i).amount), type});
                    }
                    renderSelected();
                })
                .setNegativeButton("Cancel", null).show();
    }

    private double total() {
        double t = 0;
        for (String[] s : selected) t += U.num(s[1]);
        return t;
    }

    private void renderSelected() {
        selectedBox.removeAllViews();
        selectedBox.addView(U.tv(this, "Selected tests / packages", 15, U.text(), true));
        if (selected.isEmpty()) {
            selectedBox.addView(U.tv(this, "Nothing selected. Use the buttons below.", 13, U.sub(), false),
                    U.lpm(this, -2, -2, 0, 6, 0, 0));
        }
        for (final String[] s : new ArrayList<>(selected)) {
            LinearLayout r = new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            String nm = s[2].equals("package") ? s[0] + "  (package)" : s[0];
            r.addView(U.tv(this, nm, 14, U.text(), false), U.lpw(1));
            r.addView(U.tv(this, U.money(U.num(s[1])), 14, U.text(), true));
            TextView x = U.tv(this, "  ✕", 16, U.RED, true);
            x.setPadding(U.dp(this, 10), U.dp(this, 4), U.dp(this, 4), U.dp(this, 4));
            x.setOnClickListener(v -> {
                selected.remove(s);
                renderSelected();
            });
            r.addView(x);
            selectedBox.addView(r, U.lpm(this, -1, -2, 0, 8, 0, 0));
        }
        tvTotal = U.tv(this, "", 16, U.text(), true);
        tvDue = U.tv(this, "", 13, U.sub(), false);
        selectedBox.addView(tvTotal, U.lpm(this, -2, -2, 0, 12, 0, 0));
        selectedBox.addView(tvDue);
        updateTotals();
    }

    private void updateTotals() {
        if (tvTotal == null || etDiscount == null) return;
        double t = total(), d = U.num(etDiscount.getText().toString()), p = U.num(etPaid.getText().toString());
        double net = Math.max(0, t - d);
        tvTotal.setText("Total: " + U.money(net));
        tvDue.setText("Due after payment: " + U.money(Math.max(0, net - p)));
    }

    private void submit() {
        String name = etName.getText().toString().trim();
        if (name.isEmpty()) {
            etName.setError("Required");
            etName.requestFocus();
            return;
        }
        if (etAge.getText().toString().trim().isEmpty()) {
            etAge.setError("Required");
            etAge.requestFocus();
            return;
        }
        String mobile = etMobile.getText().toString().trim();
        if (!mobile.isEmpty() && mobile.replaceAll("[^0-9]", "").length() < 10) {
            etMobile.setError("Enter a valid mobile number");
            etMobile.requestFocus();
            return;
        }
        if (selected.isEmpty()) {
            U.toast(this, "Select at least one test or package");
            return;
        }
        Booking b = new Booking();
        b.title = TITLES[spTitle.getSelectedItemPosition()];
        b.name = name;
        b.age = (int) U.num(etAge.getText().toString());
        b.ageUnit = UNITS[spUnit.getSelectedItemPosition()];
        b.gender = GENDERS[spGender.getSelectedItemPosition()];
        b.mobile = mobile;
        b.department = String.valueOf(spDept.getSelectedItem());
        b.doctor = String.valueOf(spDoc.getSelectedItem());
        b.collectedBy = String.valueOf(spStaff.getSelectedItem());
        b.info = etInfo.getText().toString().trim();
        b.description = etDesc.getText().toString().trim();
        b.important = swImportant.isChecked();
        b.ts = cal.getTimeInMillis();
        StringBuilder sb = new StringBuilder();
        for (String[] s : selected) sb.append(s[0]).append('\t').append(s[1]).append('\t').append(s[2]).append('\n');
        b.items = sb.toString();
        b.total = total();
        b.discount = Math.min(U.num(etDiscount.getText().toString()), b.total);
        b.paid = U.num(etPaid.getText().toString());
        b.commPct = U.num(etPct.getText().toString());
        double amt = U.num(etAmt.getText().toString());
        b.commAmt = amt > 0 ? amt : b.net() * b.commPct / 100.0;
        b.code = Db.get(this).nextCode(name, mobile);
        Db.get(this).saveBooking(b);
        U.toast(this, "Booking saved (" + b.code + ")");
        finish();
    }
}
