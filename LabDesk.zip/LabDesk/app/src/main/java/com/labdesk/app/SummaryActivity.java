package com.labdesk.app;

import android.os.Bundle;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Business insights: bookings, revenue, due, expenses and top tests for the chosen range. */
public class SummaryActivity extends AppCompatActivity {

    private LinearLayout content;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        U.init(this);
        U.style(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(U.bg());

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(U.dp(this, 12), U.dp(this, 8), U.dp(this, 14), U.dp(this, 8));
        FrameLayout back = U.circleBtn(this, R.drawable.ic_back);
        back.setOnClickListener(v -> finish());
        top.addView(back, U.lpm(this, 44, 44, 0, 0, 12, 0));
        top.addView(U.tv(this, "Report", 20, U.text(), true));
        root.addView(top, U.lp(-1, -2));

        ScrollView sv = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(U.dp(this, 16), U.dp(this, 2), U.dp(this, 16), U.dp(this, 20));
        sv.addView(content);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
        render();
    }

    private void render() {
        content.removeAllViews();
        LinearLayout rr = new LinearLayout(this);
        rr.setGravity(Gravity.END);
        rr.addView(Screens.rangeChip(this, this::render));
        content.addView(rr, U.lpm(this, -1, -2, 0, 0, 0, 10));

        long from = Screens.from();
        List<Booking> all = Db.get(this).bookings(null, from, Long.MAX_VALUE, null);
        int done = 0;
        double billed = 0, disc = 0, collected = 0, due = 0;
        Map<String, Integer> counts = new HashMap<>();
        for (Booking b : all) {
            if (b.completed()) done++;
            billed += b.total;
            disc += b.discount;
            collected += b.paid;
            due += b.due();
            for (String[] l : b.itemLines()) {
                Integer c = counts.get(l[0]);
                counts.put(l[0], c == null ? 1 : c + 1);
            }
        }
        double expenses = Db.get(this).sumAmountSince("expense", from);

        stat("Bookings", String.valueOf(all.size()), U.text());
        stat("Reports completed", String.valueOf(done), U.text());
        stat("Billed (before discount)", U.money(billed), U.text());
        stat("Discount given", U.money(disc), U.text());
        stat("Collected", U.money(collected), U.GREEN);
        stat("Pending due", U.money(due), due > 0 ? U.RED : U.text());
        stat("Expenses", U.money(expenses), U.text());
        stat("Collected minus expenses", U.money(collected - expenses), collected - expenses < 0 ? U.RED : U.GREEN);

        LinearLayout tc = U.card(this);
        tc.addView(U.tv(this, "Top tests", 16, U.text(), true));
        List<Map.Entry<String, Integer>> es = new ArrayList<>(counts.entrySet());
        Collections.sort(es, (x, y) -> y.getValue() - x.getValue());
        if (es.isEmpty()) tc.addView(U.tv(this, "No data in this period", 13, U.sub(), false), U.lpm(this, -2, -2, 0, 6, 0, 0));
        for (int i = 0; i < Math.min(8, es.size()); i++) {
            LinearLayout r = new LinearLayout(this);
            r.addView(U.tv(this, es.get(i).getKey(), 14, U.text(), false), U.lpw(1));
            r.addView(U.tv(this, es.get(i).getValue() + "x", 14, U.chipText(), true));
            tc.addView(r, U.lpm(this, -1, -2, 0, 8, 0, 0));
        }
        content.addView(tc, U.lpm(this, -1, -2, 0, 4, 0, 0));
    }

    private void stat(String label, String value, int color) {
        LinearLayout r = U.card(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(U.tv(this, label, 14, U.sub(), false), U.lpw(1));
        TextView v = U.tv(this, value, 18, color, true);
        r.addView(v);
        content.addView(r, U.lpm(this, -1, -2, 0, 0, 0, 8));
    }
}
