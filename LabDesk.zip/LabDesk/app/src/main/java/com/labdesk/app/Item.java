package com.labdesk.app;

import android.content.ContentValues;
import android.database.Cursor;

/** Generic master record: tests, packages, doctors, staff, expenses, wallet entries, etc. */
final class Item {
    long id;
    String type = "", name = "", extra = "";
    double amount;
    long ts = System.currentTimeMillis();

    ContentValues cv() {
        ContentValues v = new ContentValues();
        v.put("type", type);
        v.put("name", name);
        v.put("extra", extra);
        v.put("amount", amount);
        v.put("ts", ts);
        return v;
    }

    static Item from(Cursor c) {
        Item i = new Item();
        i.id = c.getLong(c.getColumnIndexOrThrow("id"));
        i.type = c.getString(c.getColumnIndexOrThrow("type"));
        i.name = c.getString(c.getColumnIndexOrThrow("name"));
        i.extra = c.getString(c.getColumnIndexOrThrow("extra"));
        if (i.extra == null) i.extra = "";
        i.amount = c.getDouble(c.getColumnIndexOrThrow("amount"));
        i.ts = c.getLong(c.getColumnIndexOrThrow("ts"));
        return i;
    }
}
