package com.labdesk.app;

import android.content.Context;
import android.content.SharedPreferences;

/** Small wrapper around SharedPreferences for app settings. */
final class Prefs {
    private Prefs() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences("labdesk", Context.MODE_PRIVATE);
    }

    static String str(Context c, String k, String d) { return p(c).getString(k, d); }
    static void put(Context c, String k, String v) { p(c).edit().putString(k, v).apply(); }
    static boolean bool(Context c, String k, boolean d) { return p(c).getBoolean(k, d); }
    static void put(Context c, String k, boolean v) { p(c).edit().putBoolean(k, v).apply(); }

    static String labName(Context c) { return str(c, "lab_name", "My Diagnostic Lab"); }
    static String labAddress(Context c) { return str(c, "lab_address", ""); }
    static String labPhone(Context c) { return str(c, "lab_phone", ""); }
    static String support(Context c) { return str(c, "support", ""); }
    static String website(Context c) { return str(c, "website", ""); }

    /** Option: hide the price column / totals on the patient report PDF. */
    static boolean hidePrice(Context c) { return bool(c, "hide_price", false); }
    static void setHidePrice(Context c, boolean v) { put(c, "hide_price", v); }

    /** "light", "dark" or "system". */
    static String theme(Context c) { return str(c, "theme", "system"); }
    static String pin(Context c) { return str(c, "pin", ""); }
    static String language(Context c) { return str(c, "language", "English"); }
    static String loading(Context c) { return str(c, "loading", "Spinner"); }
}
