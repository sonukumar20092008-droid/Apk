package com.labdesk.app;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** One patient booking / report. */
final class Booking {
    long id;
    String code = "", title = "", name = "", ageUnit = "Years", gender = "", mobile = "";
    String department = "Pathology", doctor = "Self (No Referral)", collectedBy = "";
    String description = "", info = "", status = "Booked";
    /** Lines of "name \t price \t type(test|package)" separated by newline. */
    String items = "";
    /** Lines of "testName \t value" separated by newline. */
    String results = "";
    int age;
    double commPct, commAmt, total, discount, paid;
    long ts = System.currentTimeMillis();
    boolean important;

    double net() { return Math.max(0, total - discount); }
    double due() { return Math.max(0, net() - paid); }
    boolean completed() { return "Completed".equals(status); }

    List<String[]> itemLines() {
        List<String[]> out = new ArrayList<>();
        if (items == null || items.isEmpty()) return out;
        for (String line : items.split("\n")) {
            String[] p = line.split("\t", -1);
            if (p.length >= 3) out.add(p);
        }
        return out;
    }

    String testNames() {
        StringBuilder sb = new StringBuilder();
        for (String[] l : itemLines()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(l[0]);
        }
        return sb.toString();
    }

    Map<String, String> resultMap() {
        Map<String, String> m = new LinkedHashMap<>();
        if (results == null || results.isEmpty()) return m;
        for (String line : results.split("\n")) {
            String[] p = line.split("\t", 2);
            if (p.length == 2) m.put(p[0], p[1]);
        }
        return m;
    }

    String ageText() {
        String u = ageUnit == null ? "" : ageUnit;
        String g = gender == null || gender.isEmpty() ? "" : " (" + gender.substring(0, 1) + ")";
        return age + " " + u + g;
    }

    String initials() {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty()) return "?";
        String[] parts = n.split("\\s+");
        String s = parts[0].substring(0, 1);
        if (parts.length > 1) s += parts[1].substring(0, 1);
        return s.toUpperCase();
    }

    ContentValues cv() {
        ContentValues v = new ContentValues();
        v.put("code", code);
        v.put("title", title);
        v.put("name", name);
        v.put("age", age);
        v.put("age_unit", ageUnit);
        v.put("gender", gender);
        v.put("mobile", mobile);
        v.put("department", department);
        v.put("doctor", doctor);
        v.put("comm_pct", commPct);
        v.put("comm_amt", commAmt);
        v.put("ts", ts);
        v.put("items", items);
        v.put("total", total);
        v.put("discount", discount);
        v.put("paid", paid);
        v.put("status", status);
        v.put("important", important ? 1 : 0);
        v.put("collected_by", collectedBy);
        v.put("description", description);
        v.put("info", info);
        v.put("results", results);
        return v;
    }

    private static String s(Cursor c, String col) {
        String v = c.getString(c.getColumnIndexOrThrow(col));
        return v == null ? "" : v;
    }

    static Booking from(Cursor c) {
        Booking b = new Booking();
        b.id = c.getLong(c.getColumnIndexOrThrow("id"));
        b.code = s(c, "code");
        b.title = s(c, "title");
        b.name = s(c, "name");
        b.age = c.getInt(c.getColumnIndexOrThrow("age"));
        b.ageUnit = s(c, "age_unit");
        b.gender = s(c, "gender");
        b.mobile = s(c, "mobile");
        b.department = s(c, "department");
        b.doctor = s(c, "doctor");
        b.commPct = c.getDouble(c.getColumnIndexOrThrow("comm_pct"));
        b.commAmt = c.getDouble(c.getColumnIndexOrThrow("comm_amt"));
        b.ts = c.getLong(c.getColumnIndexOrThrow("ts"));
        b.items = s(c, "items");
        b.total = c.getDouble(c.getColumnIndexOrThrow("total"));
        b.discount = c.getDouble(c.getColumnIndexOrThrow("discount"));
        b.paid = c.getDouble(c.getColumnIndexOrThrow("paid"));
        b.status = s(c, "status");
        b.important = c.getInt(c.getColumnIndexOrThrow("important")) == 1;
        b.collectedBy = s(c, "collected_by");
        b.description = s(c, "description");
        b.info = s(c, "info");
        b.results = s(c, "results");
        return b;
    }
}
