package com.labdesk.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Builds the patient report PDF.
 * When hidePrice is true the price column, totals and payment details are left out completely.
 */
final class PdfHelper {
    private static final int W = 595, H = 842, M = 36;

    private final Context ctx;
    private final Booking b;
    private final boolean hidePrice;
    private final PdfDocument doc = new PdfDocument();
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private PdfDocument.Page page;
    private Canvas cv;
    private int pageNo = 0;
    private float y;

    private PdfHelper(Context c, Booking b, boolean hidePrice) {
        this.ctx = c;
        this.b = b;
        this.hidePrice = hidePrice;
    }

    static File build(Context c, Booking b, boolean hidePrice) throws IOException {
        return new PdfHelper(c, b, hidePrice).make();
    }

    private File make() throws IOException {
        newPage();
        header();
        patientBlock();
        table();
        if (!hidePrice) totals();
        signature();
        doc.finishPage(page);

        File dir = new File(ctx.getCacheDir(), "reports");
        dir.mkdirs();
        String safe = b.name.replaceAll("[^A-Za-z0-9]+", "_");
        File f = new File(dir, "Report_" + b.code + "_" + safe + ".pdf");
        FileOutputStream os = new FileOutputStream(f);
        try {
            doc.writeTo(os);
        } finally {
            os.close();
            doc.close();
        }
        return f;
    }

    private void newPage() {
        if (page != null) doc.finishPage(page);
        page = doc.startPage(new PdfDocument.PageInfo.Builder(W, H, ++pageNo).create());
        cv = page.getCanvas();
        y = M;
    }

    private void text(String s, float x, float size, boolean bold, int color, Paint.Align align) {
        p.setTextSize(size);
        p.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        p.setColor(color);
        p.setTextAlign(align);
        cv.drawText(s, x, y, p);
    }

    private String fit(String s, float size, float maxW) {
        p.setTextSize(size);
        p.setTypeface(Typeface.DEFAULT);
        if (s == null) return "";
        while (s.length() > 1 && p.measureText(s) > maxW) s = s.substring(0, s.length() - 1);
        return s;
    }

    private void hr() {
        p.setColor(0xFFCCCCCC);
        p.setStrokeWidth(1f);
        cv.drawLine(M, y, W - M, y, p);
    }

    private static String rs(double v) {
        if (v == Math.floor(v)) return "Rs. " + (long) v;
        return "Rs. " + String.format(Locale.US, "%.2f", v);
    }

    private void header() {
        y += 18;
        text(Prefs.labName(ctx), W / 2f, 20, true, 0xFF2530C8, Paint.Align.CENTER);
        String addr = Prefs.labAddress(ctx);
        if (!addr.isEmpty()) {
            y += 16;
            text(fit(addr, 10, W - 2 * M), W / 2f, 10, false, 0xFF444444, Paint.Align.CENTER);
        }
        String ph = Prefs.labPhone(ctx);
        if (!ph.isEmpty()) {
            y += 14;
            text("Phone: " + ph, W / 2f, 10, false, 0xFF444444, Paint.Align.CENTER);
        }
        y += 12;
        hr();
        y += 20;
        text("PATIENT REPORT", W / 2f, 13, true, 0xFF111111, Paint.Align.CENTER);
        y += 10;
    }

    private void patientBlock() {
        SimpleDateFormat df = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault());
        String nm = (b.title.isEmpty() ? "" : b.title + " ") + b.name;
        float mid = W / 2f + 10;
        y += 18;
        text("Name: " + fit(nm, 11, mid - M - 50), M, 11, true, Color.BLACK, Paint.Align.LEFT);
        text("Date: " + df.format(new Date(b.ts)), mid, 11, false, Color.BLACK, Paint.Align.LEFT);
        y += 16;
        text("Age/Sex: " + b.ageText(), M, 11, false, Color.BLACK, Paint.Align.LEFT);
        text("Patient ID: " + b.code, mid, 11, false, Color.BLACK, Paint.Align.LEFT);
        y += 16;
        String mob = b.mobile.isEmpty() ? "-" : b.mobile;
        text("Mobile: " + mob, M, 11, false, Color.BLACK, Paint.Align.LEFT);
        text("Referred by: " + fit(b.doctor, 11, W - M - mid - 70), mid, 11, false, Color.BLACK, Paint.Align.LEFT);
        if (!b.collectedBy.isEmpty()) {
            y += 16;
            text("Sample collected by: " + b.collectedBy, M, 11, false, Color.BLACK, Paint.Align.LEFT);
        }
        y += 12;
        hr();
    }

    private void tableHead() {
        p.setColor(0xFFEEF0FB);
        p.setStyle(Paint.Style.FILL);
        cv.drawRect(M, y + 6, W - M, y + 26, p);
        y += 20;
        text("TEST", M + 4, 10, true, 0xFF222222, Paint.Align.LEFT);
        text("RESULT", hidePrice ? 260 : 230, 10, true, 0xFF222222, Paint.Align.LEFT);
        text("UNIT", hidePrice ? 370 : 320, 10, true, 0xFF222222, Paint.Align.LEFT);
        text("REFERENCE", hidePrice ? 440 : 390, 10, true, 0xFF222222, Paint.Align.LEFT);
        if (!hidePrice) text("PRICE", W - M - 4, 10, true, 0xFF222222, Paint.Align.RIGHT);
        y += 6;
    }

    private void table() {
        y += 6;
        tableHead();
        List<String[]> rows = Db.get(ctx).reportRows(b);
        for (String[] r : rows) {
            if (y > H - 110) {
                newPage();
                y += 10;
                tableHead();
            }
            y += 20;
            boolean head = "H".equals(r[5]);
            text(fit(r[0], 11, (hidePrice ? 215 : 185) - M), M + 4, 11, head, Color.BLACK, Paint.Align.LEFT);
            if (!head) {
                text(r[1].isEmpty() ? "-" : fit(r[1], 11, 85), hidePrice ? 260 : 230, 11, true, Color.BLACK, Paint.Align.LEFT);
                text(fit(r[2], 10, 65), hidePrice ? 370 : 320, 10, false, 0xFF444444, Paint.Align.LEFT);
                text(fit(r[3], 10, hidePrice ? 115 : 100), hidePrice ? 440 : 390, 10, false, 0xFF444444, Paint.Align.LEFT);
            }
            if (!hidePrice && !r[4].isEmpty()) {
                text(rs(U.num(r[4])), W - M - 4, 11, false, Color.BLACK, Paint.Align.RIGHT);
            }
            y += 4;
            p.setColor(0xFFE5E5E5);
            cv.drawLine(M, y, W - M, y, p);
        }
        y += 6;
    }

    private void totals() {
        if (y > H - 150) newPage();
        float x = W - M - 4;
        y += 20;
        text("Total: " + rs(b.total), x, 11, false, Color.BLACK, Paint.Align.RIGHT);
        if (b.discount > 0) {
            y += 16;
            text("Discount: - " + rs(b.discount), x, 11, false, Color.BLACK, Paint.Align.RIGHT);
        }
        y += 16;
        text("Net amount: " + rs(b.net()), x, 12, true, Color.BLACK, Paint.Align.RIGHT);
        y += 16;
        text("Paid: " + rs(b.paid), x, 11, false, Color.BLACK, Paint.Align.RIGHT);
        y += 16;
        text("Due: " + rs(b.due()), x, 11, true, b.due() > 0 ? 0xFFC62828 : 0xFF2E7D32, Paint.Align.RIGHT);
    }

    private void signature() {
        if (y > H - 110) newPage();
        y = Math.max(y + 50, H - 90);
        p.setColor(0xFF888888);
        cv.drawLine(W - M - 150, y, W - M, y, p);
        y += 14;
        text("Authorised Signatory", W - M, 10, false, 0xFF444444, Paint.Align.RIGHT);
        y += 22;
        text("This report is computer generated. Please correlate clinically.", W / 2f, 9, false, 0xFF888888,
                Paint.Align.CENTER);
    }
}
