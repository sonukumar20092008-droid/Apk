package com.labdesk.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** UI helpers: colors, dp, common views. All screens are built in code. */
final class U {
    private U() {}

    interface Str { void run(String s); }

    static boolean dark = false;
    static final int PRIMARY = 0xFF2530C8;
    static final int GREEN = 0xFF43A047;
    static final int ORANGE = 0xFFFF8A5B;
    static final int RED = 0xFFE53935;
    static final int AMBER = 0xFFFFB300;

    static int bg() { return dark ? 0xFF111318 : 0xFFF4F6FB; }
    static int card() { return dark ? 0xFF1D2028 : 0xFFFFFFFF; }
    static int text() { return dark ? 0xFFF3F4F6 : 0xFF111827; }
    static int sub() { return dark ? 0xFF9CA3AF : 0xFF6B7280; }
    static int line() { return dark ? 0xFF2D313B : 0xFFE5E7EB; }
    static int chip() { return dark ? 0xFF2A2F55 : 0xFFE0E3F7; }
    static int chipText() { return dark ? 0xFFB9C0FF : PRIMARY; }

    static void init(Context c) {
        String t = Prefs.theme(c);
        if ("dark".equals(t)) {
            dark = true;
        } else if ("light".equals(t)) {
            dark = false;
        } else {
            int m = c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            dark = m == Configuration.UI_MODE_NIGHT_YES;
        }
    }

    /** Status bar / navigation bar colours and window background. */
    static void style(Activity a) {
        a.getWindow().setStatusBarColor(bg());
        a.getWindow().setNavigationBarColor(card());
        a.getWindow().getDecorView().setBackgroundColor(bg());
        View decor = a.getWindow().getDecorView();
        int f = decor.getSystemUiVisibility();
        if (dark) {
            f &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        } else {
            f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        }
        decor.setSystemUiVisibility(f);
    }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable rect(Context c, int color, float rDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, rDp));
        return g;
    }

    static GradientDrawable rect(Context c, int color, float rDp, int stroke) {
        GradientDrawable g = rect(c, color, rDp);
        g.setStroke(dp(c, 1), stroke);
        return g;
    }

    static GradientDrawable oval(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    static TextView tv(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static ImageView icon(Context c, int res, int tint, int sizeDp) {
        ImageView i = new ImageView(c);
        i.setImageResource(res);
        i.setColorFilter(tint, PorterDuff.Mode.SRC_IN);
        i.setLayoutParams(new LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp)));
        return i;
    }

    /** Round button with an icon (menu, search, profile...). */
    static FrameLayout circleBtn(Context c, int iconRes) {
        FrameLayout f = new FrameLayout(c);
        f.setBackground(oval(card()));
        f.setElevation(dp(c, 1));
        ImageView i = icon(c, iconRes, text(), 22);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(c, 22), dp(c, 22), Gravity.CENTER);
        f.addView(i, lp);
        f.setClickable(true);
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(c, 44), dp(c, 44)));
        return f;
    }

    static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(rect(c, card(), 16));
        l.setElevation(dp(c, 2));
        int p = dp(c, 14);
        l.setPadding(p, p, p, p);
        return l;
    }

    static LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    static LinearLayout.LayoutParams lpw(float weight) {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
    }

    /** Layout params with margins in dp. */
    static LinearLayout.LayoutParams lpm(Context c, int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    /** Weighted (horizontal) layout params with margins in dp. */
    static LinearLayout.LayoutParams lpmw(Context c, float weight, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    static EditText et(Context c, String hint, int inputType) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setInputType(inputType);
        e.setTextSize(15);
        e.setTextColor(text());
        e.setHintTextColor(sub());
        e.setBackground(rect(c, card(), 14, line()));
        int ph = dp(c, 14), pv = dp(c, 14);
        e.setPadding(ph, pv, ph, pv);
        return e;
    }

    static TextView pill(Context c, String s, int bgColor, int fg) {
        TextView t = tv(c, s, 12, fg, true);
        t.setBackground(rect(c, bgColor, 20));
        int h = dp(c, 12), v = dp(c, 5);
        t.setPadding(h, v, h, v);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    static String money(double v) {
        if (v == Math.floor(v)) return "₹" + (long) v;
        return "₹" + String.format(Locale.US, "%.2f", v);
    }

    static double num(String s) {
        try {
            return Double.parseDouble(s.trim());
        } catch (Exception e) {
            return 0;
        }
    }

    static void toast(Context c, String s) {
        Toast.makeText(c, s, Toast.LENGTH_SHORT).show();
    }

    static void prompt(Context c, String title, String hint, String def, int inputType, final Str cb) {
        final EditText e = new EditText(c);
        e.setHint(hint);
        e.setInputType(inputType);
        e.setText(def);
        e.setSelection(e.getText().length());
        FrameLayout f = new FrameLayout(c);
        f.setPadding(dp(c, 20), dp(c, 8), dp(c, 20), 0);
        f.addView(e);
        new AlertDialog.Builder(c)
                .setTitle(title)
                .setView(f)
                .setPositiveButton("OK", (d, w) -> cb.run(e.getText().toString().trim()))
                .setNegativeButton("Cancel", null)
                .show();
    }

    static void info(Context c, String title, String msg) {
        new AlertDialog.Builder(c).setTitle(title).setMessage(msg).setPositiveButton("OK", null).show();
    }

    static final int T_TEXT = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS;
    static final int T_NUM = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL;
    static final int T_PHONE = InputType.TYPE_CLASS_PHONE;
}
