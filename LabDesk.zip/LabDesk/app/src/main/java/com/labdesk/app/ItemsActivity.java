package com.labdesk.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** One generic list + add/edit/delete screen used for all master data (tests, doctors, staff, expenses...). */
public class ItemsActivity extends AppCompatActivity {

    static void open(Context c, String type) {
        Intent i = new Intent(c, ItemsActivity.class);
        i.putExtra("type", type);
        c.startActivity(i);
    }

    private String type;
    private String[] cfg; // title, nameHint, extraHint, amountHint, totalLabel
    private LinearLayout list;
    private LinearLayout totalBox;

    /** title, nameHint, extraHint (null = hidden), amountHint (null = hidden), totalLabel (null = none) */
    private static String[] config(String t) {
        switch (t) {
            case "department": return new String[]{"Manage Pathology", "Department name", null, null, null};
            case "test": return new String[]{"Lab Tests", "Test name", "Unit | Reference range  (e.g. g/dL|13 - 17)", "Price", null};
            case "package": return new String[]{"Packages", "Package name", "Included tests, comma separated (exact test names)", "Price", null};
            case "center": return new String[]{"Collection Centers", "Center name", "Address / phone", null, null};
            case "nabl": return new String[]{"NABL & Quality", "Document / note title", "Details", null, null};
            case "doctor": return new String[]{"Referrals", "Doctor / referrer name", "Phone", "Default commission (%)", null};
            case "outsource": return new String[]{"Outsource Labs", "Lab name", "Contact / address", null, null};
            case "insource": return new String[]{"Insource Labs", "Lab name", "Contact / address", null, null};
            case "expense": return new String[]{"Finance & Expenses", "Expense title", "Note", "Amount", "Total expenses"};
            case "account": return new String[]{"Staff & Referral Accounts", "Account holder", "Note (staff / referral)", "Balance", "Total balance"};
            case "wallet": return new String[]{"Wallet Management", "Description", null, "Amount (negative to deduct)", "Balance"};
            case "inventory": return new String[]{"Inventory", "Item name", "Quantity / unit", "Unit cost", null};
            case "user": return new String[]{"Manage Users", "User name", "Role / phone", null, null};
            case "role": return new String[]{"Manage Roles", "Role name", "Permissions / notes", null, null};
            case "staff": return new String[]{"Manage Staff", "Staff name", "Role / phone", "Monthly salary", "Monthly payroll"};
            default: return new String[]{"Patients", "", null, null, null};
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        U.init(this);
        U.style(this);
        type = getIntent().getStringExtra("type");
        if (type == null) type = "patients";
        cfg = config(type);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(U.bg());

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(U.dp(this, 12), U.dp(this, 8), U.dp(this, 14), U.dp(this, 8));
        FrameLayout back = U.circleBtn(this, R.drawable.ic_back);
        back.setOnClickListener(v -> finish());
        top.addView(back, U.lpm(this, 44, 44, 0, 0, 12, 0));
        top.addView(U.tv(this, cfg[0], 20, U.text(), true));
        root.addView(top, U.lp(-1, -2));

        totalBox = new LinearLayout(this);
        totalBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(totalBox, U.lpm(this, -1, -2, 16, 0, 16, 8));

        ScrollView sv = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(U.dp(this, 16), U.dp(this, 2), U.dp(this, 16), U.dp(this, 16));
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        if (!type.equals("patients")) {
            TextView add = U.tv(this, "+  Add", 16, Color.WHITE, true);
            add.setGravity(Gravity.CENTER);
            add.setBackground(U.rect(this, U.PRIMARY, 16));
            add.setOnClickListener(v -> edit(null));
            root.addView(add, U.lpm(this, -1, U.dp(this, 54), 16, 4, 16, 16));
        }
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        list.removeAllViews();
        totalBox.removeAllViews();
        if (type.equals("patients")) {
            showPatients();
            return;
        }
        List<Item> items = Db.get(this).items(type);
        if (cfg[4] != null) {
            double sum = 0;
            for (Item i : items) sum += i.amount;
            LinearLayout c = U.card(this);
            c.addView(U.tv(this, cfg[4], 12, U.sub(), false));
            c.addView(U.tv(this, U.money(sum), 24, sum < 0 ? U.RED : U.text(), true));
            totalBox.addView(c);
        }
        if (items.isEmpty()) {
            TextView e = U.tv(this, "Nothing here yet. Tap Add.", 14, U.sub(), false);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0, U.dp(this, 50), 0, 0);
            list.addView(e, U.lp(-1, -2));
        }
        boolean dated = type.equals("expense") || type.equals("wallet");
        SimpleDateFormat df = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault());
        for (final Item it : items) {
            LinearLayout row = U.card(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout t = new LinearLayout(this);
            t.setOrientation(LinearLayout.VERTICAL);
            t.addView(U.tv(this, it.name, 16, U.text(), true));
            String sub = it.extra;
            if (dated) sub = (sub.isEmpty() ? "" : sub + "  ·  ") + df.format(new Date(it.ts));
            if (!sub.isEmpty()) t.addView(U.tv(this, sub, 13, U.sub(), false));
            row.addView(t, U.lpw(1));
            if (cfg[3] != null) {
                String a = type.equals("doctor") ? (it.amount == 0 ? "" : trim(it.amount) + "%") : U.money(it.amount);
                if (!a.isEmpty()) row.addView(U.tv(this, a, 16, it.amount < 0 ? U.RED : U.chipText(), true));
            }
            row.setOnClickListener(v -> edit(it));
            list.addView(row, U.lpm(this, -1, -2, 0, 0, 0, 10));
        }
    }

    private static String trim(double v) {
        return v == Math.floor(v) ? String.valueOf((long) v) : String.valueOf(v);
    }

    private void showPatients() {
        List<String[]> ps = Db.get(this).patients();
        if (ps.isEmpty()) {
            TextView e = U.tv(this, "No patients yet. They appear here after the first booking.", 14, U.sub(), false);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0, U.dp(this, 50), 0, 0);
            list.addView(e, U.lp(-1, -2));
        }
        for (String[] p : ps) {
            LinearLayout row = U.card(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout t = new LinearLayout(this);
            t.setOrientation(LinearLayout.VERTICAL);
            t.addView(U.tv(this, p[1], 16, U.text(), true));
            t.addView(U.tv(this, p[0] + " · " + p[2] + (p[3].isEmpty() ? "" : " · " + p[3]), 13, U.sub(), false));
            t.addView(U.tv(this, p[4] + (p[4].equals("1") ? " visit" : " visits"), 12, U.sub(), false));
            row.addView(t, U.lpw(1));
            double due = U.num(p[5]);
            if (due > 0) row.addView(U.pill(this, "Due " + U.money(due), U.dark ? 0x33E53935 : 0xFFFDECEA, U.RED));
            list.addView(row, U.lpm(this, -1, -2, 0, 0, 0, 10));
        }
    }

    private void edit(final Item existing) {
        final Item it = existing != null ? existing : new Item();
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(U.dp(this, 20), U.dp(this, 8), U.dp(this, 20), 0);
        final EditText n = new EditText(this);
        n.setHint(cfg[1]);
        n.setInputType(U.T_TEXT);
        n.setText(it.name);
        f.addView(n);
        EditText ex = null, am = null;
        if (cfg[2] != null) {
            ex = new EditText(this);
            ex.setHint(cfg[2]);
            ex.setInputType(U.T_TEXT);
            ex.setText(it.extra);
            f.addView(ex);
        }
        if (cfg[3] != null) {
            am = new EditText(this);
            am.setHint(cfg[3]);
            am.setInputType(U.T_NUM | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
            if (existing != null) am.setText(trim(it.amount));
            f.addView(am);
        }
        final EditText fex = ex, fam = am;
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle(existing == null ? "Add" : "Edit")
                .setView(f)
                .setPositiveButton("Save", (d, w) -> {
                    String name = n.getText().toString().trim();
                    if (name.isEmpty()) {
                        U.toast(this, "Name is required");
                        return;
                    }
                    it.type = type;
                    it.name = name;
                    if (fex != null) it.extra = fex.getText().toString().trim();
                    if (fam != null) it.amount = U.num(fam.getText().toString());
                    if (existing == null) it.ts = System.currentTimeMillis();
                    Db.get(this).saveItem(it);
                    refresh();
                })
                .setNegativeButton("Cancel", null);
        if (existing != null) {
            b.setNeutralButton("Delete", (d, w) -> {
                Db.get(this).deleteItem(it.id);
                refresh();
            });
        }
        b.show();
    }
}
