package com.labdesk.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.widget.SwitchCompat;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Builds the 4 main tab screens: Dashboard, Bookings, Reports, Settings. */
final class Screens {
    private Screens() {}

    static int range = 1;
    static final String[] RANGE_NAMES = {"Today", "Last 7 Days", "Last 30 Days", "All Time"};
    private static final long DAY = 24L * 3600 * 1000;

    static long startOfToday() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    static long from() {
        long t = startOfToday();
        switch (range) {
            case 0: return t;
            case 1: return t - 6 * DAY;
            case 2: return t - 29 * DAY;
            default: return 0;
        }
    }

    static TextView rangeChip(final Activity a, final Runnable changed) {
        TextView t = U.tv(a, RANGE_NAMES[range] + "  ▾", 13, U.chipText(), true);
        t.setBackground(U.rect(a, U.chip(), 20));
        t.setPadding(U.dp(a, 16), U.dp(a, 9), U.dp(a, 16), U.dp(a, 9));
        t.setOnClickListener(v -> new AlertDialog.Builder(a)
                .setTitle("Date range")
                .setSingleChoiceItems(RANGE_NAMES, range, (d, which) -> {
                    range = which;
                    d.dismiss();
                    changed.run();
                })
                .show());
        return t;
    }

    private static LinearLayout column(Activity a) {
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(U.dp(a, 16), U.dp(a, 4), U.dp(a, 16), U.dp(a, 24));
        return col;
    }

    private static ScrollView scroll(Activity a, View content) {
        ScrollView sv = new ScrollView(a);
        sv.setFillViewport(true);
        sv.addView(content, new ViewGroup.LayoutParams(-1, -2));
        return sv;
    }

    // ------------------------------------------------------------------ DASHBOARD

    static View dashboard(final Activity a, final Runnable refresh) {
        final MainActivity main = (MainActivity) a;
        Db db = Db.get(a);
        LinearLayout col = column(a);

        // Title row + wallet chip
        LinearLayout titleRow = new LinearLayout(a);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(U.tv(a, "Dashboard", 22, U.text(), true), U.lpw(1));
        double bal = db.sumAmount("wallet");
        LinearLayout wallet = new LinearLayout(a);
        wallet.setGravity(Gravity.CENTER_VERTICAL);
        wallet.setBackground(U.rect(a, U.card(), 20, U.line()));
        wallet.setPadding(U.dp(a, 12), U.dp(a, 8), U.dp(a, 14), U.dp(a, 8));
        wallet.addView(U.icon(a, R.drawable.ic_wallet, U.PRIMARY, 18));
        TextView wt = U.tv(a, U.money(bal), 14, U.text(), true);
        wt.setPadding(U.dp(a, 6), 0, 0, 0);
        wallet.addView(wt);
        wallet.setOnClickListener(v -> ItemsActivity.open(a, "wallet"));
        titleRow.addView(wallet);
        col.addView(titleRow, U.lpm(a, -1, -2, 0, 4, 0, 12));

        // Support card
        final String sup = Prefs.support(a);
        LinearLayout sc = U.card(a);
        sc.setOrientation(LinearLayout.HORIZONTAL);
        sc.setGravity(Gravity.CENTER_VERTICAL);
        sc.addView(U.icon(a, R.drawable.ic_person, U.PRIMARY, 26), U.lpm(a, 26, 26, 0, 0, 12, 0));
        LinearLayout st = new LinearLayout(a);
        st.setOrientation(LinearLayout.VERTICAL);
        st.addView(U.tv(a, "Need help? Call support", 12, U.sub(), false));
        st.addView(U.tv(a, sup.isEmpty() ? "Add support number in Settings" : sup, sup.isEmpty() ? 13 : 17, U.text(), true));
        sc.addView(st, U.lpw(1));
        if (!sup.isEmpty()) {
            FrameLayout call = U.circleBtn(a, R.drawable.ic_phone);
            call.setOnClickListener(v -> a.startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + sup))));
            sc.addView(call, U.lpm(a, 44, 44, 6, 0, 6, 0));
            FrameLayout wa = U.circleBtn(a, R.drawable.ic_info);
            wa.setOnClickListener(v -> {
                String d = sup.replaceAll("[^0-9]", "");
                if (d.length() == 10) d = "91" + d;
                a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + d)));
            });
            sc.addView(wa);
        }
        col.addView(sc, U.lp(-1, -2));

        // Range chip
        LinearLayout rr = new LinearLayout(a);
        rr.setGravity(Gravity.END);
        rr.addView(rangeChip(a, refresh));
        col.addView(rr, U.lpm(a, -1, -2, 0, 12, 0, 12));

        // Metric cards
        List<Booking> all = db.bookings(null, from(), Long.MAX_VALUE, null);
        int booked = 0, done = 0;
        for (Booking b : all) {
            if (b.completed()) done++;
            else booked++;
        }
        LinearLayout metrics = new LinearLayout(a);
        metrics.addView(metric(a, R.drawable.ic_calendar, String.valueOf(booked), "New Booking",
                0xFF8BC34A, 0xFF4CAF50, v -> main.showTab(1)), U.lpmw(a, 1, 0, 0, 5, 0));
        metrics.addView(metric(a, R.drawable.ic_dashboard, String.valueOf(all.size()), "Total Bookings",
                0xFFFFA06B, 0xFFFF8A5B, v -> main.showTab(1)), U.lpmw(a, 1, 5, 0, 5, 0));
        metrics.addView(metric(a, R.drawable.ic_reports, String.valueOf(done), "Total Reports",
                0xFFB07CD8, 0xFFEE7BA0, v -> main.showTab(2)), U.lpmw(a, 1, 5, 0, 0, 0));
        col.addView(metrics, U.lp(-1, -2));

        // Chart card
        int days = range == 0 ? 1 : range == 1 ? 7 : 30;
        long start = startOfToday() - (days - 1) * DAY;
        int[] bk = new int[days], cm = new int[days];
        String[] lb = new String[days];
        SimpleDateFormat df = new SimpleDateFormat("d/M", Locale.getDefault());
        for (int i = 0; i < days; i++) lb[i] = days == 1 ? "Today" : df.format(new Date(start + i * DAY));
        int shown = 0;
        for (Booking b : db.bookings(null, start, Long.MAX_VALUE, null)) {
            int idx = (int) Math.round((double) (startOfDay(b.ts) - start) / DAY);
            if (idx < 0 || idx >= days) continue;
            shown++;
            if (b.completed()) cm[idx]++;
            else bk[idx]++;
        }
        LinearLayout cc = U.card(a);
        cc.addView(U.tv(a, "Bookings overview", 17, U.text(), true));
        cc.addView(U.tv(a, shown + " bookings over " + days + (days == 1 ? " day" : " days"), 13, U.sub(), false));
        LinearLayout legend = new LinearLayout(a);
        legend.setGravity(Gravity.CENTER_VERTICAL);
        legend.addView(dot(a, U.PRIMARY));
        legend.addView(U.tv(a, "  Booked     ", 13, U.sub(), false));
        legend.addView(dot(a, U.GREEN));
        legend.addView(U.tv(a, "  Completed", 13, U.sub(), false));
        cc.addView(legend, U.lpm(a, -1, -2, 0, 10, 0, 6));
        BarChartView chart = new BarChartView(a);
        chart.set(bk, cm, lb);
        cc.addView(chart, U.lp(-1, U.dp(a, 180)));
        col.addView(cc, U.lpm(a, -1, -2, 0, 14, 0, 0));

        return scroll(a, col);
    }

    private static long startOfDay(long ts) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ts);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private static View dot(Activity a, int color) {
        View v = new View(a);
        v.setBackground(U.oval(color));
        v.setLayoutParams(new LinearLayout.LayoutParams(U.dp(a, 10), U.dp(a, 10)));
        return v;
    }

    private static View metric(Activity a, int icon, String num, String label, int c1, int c2, View.OnClickListener l) {
        LinearLayout m = new LinearLayout(a);
        m.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        g.setCornerRadius(U.dp(a, 20));
        m.setBackground(g);
        m.setPadding(U.dp(a, 12), U.dp(a, 12), U.dp(a, 12), U.dp(a, 14));
        LinearLayout top = new LinearLayout(a);
        top.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout chip = new FrameLayout(a);
        chip.setBackground(U.rect(a, 0xEEFFFFFF, 10));
        ImageView ic = U.icon(a, icon, 0xFF444444, 20);
        chip.addView(ic, new FrameLayout.LayoutParams(U.dp(a, 20), U.dp(a, 20), Gravity.CENTER));
        top.addView(chip, new LinearLayout.LayoutParams(U.dp(a, 38), U.dp(a, 38)));
        View sp = new View(a);
        top.addView(sp, U.lpw(1));
        top.addView(U.tv(a, "↗", 16, Color.WHITE, true));
        m.addView(top, U.lp(-1, -2));
        m.addView(U.tv(a, num, 30, Color.WHITE, true), U.lpm(a, -2, -2, 0, 14, 0, 0));
        m.addView(U.tv(a, label, 12, Color.WHITE, false));
        m.setOnClickListener(l);
        return m;
    }

    // ------------------------------------------------------------------ BOOKING / REPORT LISTS

    static View bookingList(final Activity a, final String status, String query, final Runnable refresh) {
        LinearLayout col = column(a);
        LinearLayout rr = new LinearLayout(a);
        rr.setGravity(Gravity.END);
        rr.addView(rangeChip(a, refresh));
        col.addView(rr, U.lpm(a, -1, -2, 0, 0, 0, 10));

        List<Booking> list = Db.get(a).bookings(status, from(), Long.MAX_VALUE, query);
        if (list.isEmpty()) {
            TextView e = U.tv(a, "Completed".equals(status) ? "No reports in this period" : "No bookings in this period",
                    15, U.sub(), false);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0, U.dp(a, 60), 0, 0);
            col.addView(e, U.lp(-1, -2));
            TextView h = U.tv(a, "Tap + to add a new booking", 13, U.sub(), false);
            h.setGravity(Gravity.CENTER);
            col.addView(h, U.lp(-1, -2));
        }
        for (Booking b : list) col.addView(bookingCard(a, b, refresh), U.lpm(a, -1, -2, 0, 0, 0, 10));
        return scroll(a, col);
    }

    private static View bookingCard(final Activity a, final Booking b, final Runnable refresh) {
        LinearLayout outer = new LinearLayout(a);
        outer.setBackground(U.rect(a, U.card(), 18));
        outer.setElevation(U.dp(a, 2));
        outer.setClipToOutline(true);

        View stripe = new View(a);
        stripe.setBackgroundColor(b.completed() ? U.GREEN : U.PRIMARY);
        outer.addView(stripe, new LinearLayout.LayoutParams(U.dp(a, 5), ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout in = new LinearLayout(a);
        in.setOrientation(LinearLayout.VERTICAL);
        in.setPadding(U.dp(a, 14), U.dp(a, 14), U.dp(a, 14), U.dp(a, 12));
        outer.addView(in, U.lpw(1));

        // row 1
        LinearLayout r1 = new LinearLayout(a);
        r1.setGravity(Gravity.CENTER_VERTICAL);
        TextView av = U.tv(a, b.initials(), 16, Color.WHITE, true);
        av.setGravity(Gravity.CENTER);
        GradientDrawable ag = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFFFFA06B, 0xFFFF6F61});
        ag.setShape(GradientDrawable.OVAL);
        av.setBackground(ag);
        r1.addView(av, new LinearLayout.LayoutParams(U.dp(a, 46), U.dp(a, 46)));
        LinearLayout names = new LinearLayout(a);
        names.setOrientation(LinearLayout.VERTICAL);
        LinearLayout nr = new LinearLayout(a);
        nr.setGravity(Gravity.CENTER_VERTICAL);
        TextView nm = U.tv(a, b.name, 16, U.text(), true);
        nm.setSingleLine(true);
        nm.setEllipsize(TextUtils.TruncateAt.END);
        nr.addView(nm, U.lp(-2, -2));
        if (b.important) nr.addView(U.icon(a, R.drawable.ic_star, U.AMBER, 16), U.lpm(a, 16, 16, 4, 0, 0, 0));
        names.addView(nr);
        names.addView(U.tv(a, b.code + " · " + b.ageText(), 13, U.sub(), false));
        r1.addView(names, U.lpmw(a, 1, 12, 0, 6, 0));

        LinearLayout right = new LinearLayout(a);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.END);
        right.addView(b.completed()
                ? U.pill(a, "✓ Completed", dark(0x22438F46, 0xFFE8F5E9), U.GREEN)
                : U.pill(a, "Booked", dark(0x332530C8, 0xFFE8EAF6), U.chipText()));
        final TextView act = U.pill(a, "Action ▾", U.ORANGE, Color.WHITE);
        right.addView(act, U.lpm(a, -2, -2, 0, 6, 0, 0));
        r1.addView(right);
        in.addView(r1, U.lp(-1, -2));

        // referral
        LinearLayout rf = new LinearLayout(a);
        rf.setGravity(Gravity.CENTER_VERTICAL);
        rf.addView(U.icon(a, R.drawable.ic_info, U.sub(), 18));
        String doc = b.doctor.startsWith("Self") ? "Self" : b.doctor;
        rf.addView(U.tv(a, "  " + doc, 14, U.text(), false));
        in.addView(rf, U.lpm(a, -1, -2, 0, 10, 0, 0));

        // test chips
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(a);
        for (String[] l : b.itemLines()) {
            TextView c = U.tv(a, l[0], 13, U.chipText(), true);
            c.setBackground(U.rect(a, U.chip(), 8));
            c.setPadding(U.dp(a, 10), U.dp(a, 4), U.dp(a, 10), U.dp(a, 4));
            chips.addView(c, U.lpm(a, -2, -2, 0, 0, 6, 0));
        }
        hs.addView(chips);
        in.addView(hs, U.lpm(a, -1, -2, 0, 8, 0, 0));

        // footer
        LinearLayout ft = new LinearLayout(a);
        ft.setGravity(Gravity.CENTER_VERTICAL);
        SimpleDateFormat df = new SimpleDateFormat("MMM d, yyyy hh:mm a", Locale.getDefault());
        ft.addView(U.tv(a, df.format(new Date(b.ts)), 12, U.sub(), false), U.lpw(1));
        ft.addView(U.tv(a, U.money(b.net()), 16, U.text(), true));
        if (b.due() > 0) {
            ft.addView(U.pill(a, "Due " + U.money(b.due()), dark(0x33E53935, 0xFFFDECEA), U.RED),
                    U.lpm(a, -2, -2, 8, 0, 0, 0));
        } else {
            ft.addView(U.pill(a, "Paid", dark(0x2243A047, 0xFFE8F5E9), U.GREEN), U.lpm(a, -2, -2, 8, 0, 0, 0));
        }
        in.addView(ft, U.lpm(a, -1, -2, 0, 10, 0, 0));

        View.OnClickListener open = v -> Actions.menu(a, act, b, refresh);
        act.setOnClickListener(open);
        outer.setOnClickListener(open);
        return outer;
    }

    private static int dark(int darkColor, int lightColor) { return U.dark ? darkColor : lightColor; }

    // ------------------------------------------------------------------ SETTINGS

    static View settings(final Activity a, final Runnable refresh) {
        final MainActivity main = (MainActivity) a;
        LinearLayout col = column(a);

        // Hide price option (on/off)
        LinearLayout hp = settingRow(a, R.drawable.ic_lock, "Hide price list on patient report",
                "ON: report PDF will not show prices, total, paid or due.");
        final SwitchCompat sw = new SwitchCompat(a);
        sw.setChecked(Prefs.hidePrice(a));
        sw.setOnCheckedChangeListener((b, on) -> {
            Prefs.setHidePrice(a, on);
            U.toast(a, on ? "Prices will be hidden on reports" : "Prices will be shown on reports");
        });
        hp.removeViewAt(hp.getChildCount() - 1);
        hp.addView(sw);
        hp.setOnClickListener(v -> sw.toggle());
        col.addView(hp, U.lpm(a, -1, -2, 0, 4, 0, 10));

        add(col, a, R.drawable.ic_info, "Lab Details", "Name, address and phone printed on the report",
                v -> labDialog(a, refresh));
        add(col, a, R.drawable.ic_lock, "Security", "Protect your app with a PIN lock", v -> security(a));
        add(col, a, R.drawable.ic_lock, "Change Password", "Change your app PIN.", v -> changePin(a));
        add(col, a, R.drawable.ic_info, "Check App Update", "Check if a new version of the app is available.",
                v -> U.info(a, "LabDesk", "You are using version 1.0.\nInstall a newer APK to update."));
        add(col, a, R.drawable.ic_info, "Loading Animation", "Choose how the app shows loading progress. (" + Prefs.loading(a) + ")",
                v -> choose(a, "Loading Animation", new String[]{"Spinner", "Dots", "Progress bar"}, "loading", null));
        add(col, a, R.drawable.ic_info, "Language", "Choose the language of the app. (" + Prefs.language(a) + ")",
                v -> choose(a, "Language", new String[]{"English", "Hindi"}, "language", null));
        add(col, a, R.drawable.ic_dashboard, "Theme", "Change app appearance. (" + Prefs.theme(a) + ")",
                v -> choose(a, "Theme", new String[]{"light", "dark", "system"}, "theme", () -> {
                    U.init(a);
                    a.recreate();
                }));
        add(col, a, R.drawable.ic_info, "Share App", "Share this app with doctors, labs, friends/family.", v -> main.shareApp());
        add(col, a, R.drawable.ic_phone, "Help & Support", "We're here to assist you with any questions or concerns.", v -> {
            String s = Prefs.support(a);
            if (s.isEmpty()) U.info(a, "Help & Support", "Add your support number in Lab Details first.");
            else a.startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + s)));
        });
        add(col, a, R.drawable.ic_star, "Rate Us", "Rate us your experience on the Play Store.", v -> {
            try {
                a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + a.getPackageName())));
            } catch (Exception e) {
                a.startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=" + a.getPackageName())));
            }
        });
        add(col, a, R.drawable.ic_info, "Website", "Visit our official website for more information and updates.", v -> {
            String w = Prefs.website(a);
            if (w.isEmpty()) {
                U.prompt(a, "Website", "https://", "", InputType.TYPE_TEXT_VARIATION_URI, s -> {
                    if (s.isEmpty()) return;
                    Prefs.put(a, "website", s);
                    openUrl(a, s);
                });
            } else {
                openUrl(a, w);
            }
        });
        add(col, a, R.drawable.ic_lock, "Privacy Policy", "How we collect, use and protect your data.",
                v -> U.info(a, "Privacy Policy", "All data (patients, bookings, reports) is stored only on this device. "
                        + "Nothing is uploaded to any server. Reports leave the phone only when you share them."));
        add(col, a, R.drawable.ic_info, "Terms & Conditions", "The terms that apply when you use the app.",
                v -> U.info(a, "Terms & Conditions", "This app is a record-keeping tool. The lab is responsible for the "
                        + "accuracy of every report it issues. Keep regular backups of your phone."));
        return scroll(a, col);
    }

    private static void openUrl(Activity a, String url) {
        if (!url.startsWith("http")) url = "https://" + url;
        a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }

    private static void choose(final Activity a, String title, final String[] opts, final String key, final Runnable after) {
        String cur = Prefs.str(a, key, key.equals("theme") ? "system" : opts[0]);
        int sel = 0;
        for (int i = 0; i < opts.length; i++) if (opts[i].equals(cur)) sel = i;
        new AlertDialog.Builder(a).setTitle(title).setSingleChoiceItems(opts, sel, (d, w) -> {
            Prefs.put(a, key, opts[w]);
            d.dismiss();
            if (after != null) after.run();
            else ((MainActivity) a).showTab(3);
        }).show();
    }

    private static void add(LinearLayout col, Activity a, int icon, String t, String s, View.OnClickListener l) {
        LinearLayout r = settingRow(a, icon, t, s);
        r.setOnClickListener(l);
        col.addView(r, U.lpm(a, -1, -2, 0, 0, 0, 10));
    }

    /** Card row: icon, title + subtitle, arrow circle (last child; replaced by a switch for toggles). */
    private static LinearLayout settingRow(Activity a, int icon, String title, String sub) {
        LinearLayout r = U.card(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout ic = new FrameLayout(a);
        ic.setBackground(U.oval(U.chip()));
        ic.addView(U.icon(a, icon, U.chipText(), 22), new FrameLayout.LayoutParams(U.dp(a, 22), U.dp(a, 22), Gravity.CENTER));
        r.addView(ic, U.lpm(a, 46, 46, 0, 0, 12, 0));
        LinearLayout t = new LinearLayout(a);
        t.setOrientation(LinearLayout.VERTICAL);
        t.addView(U.tv(a, title, 16, U.text(), true));
        t.addView(U.tv(a, sub, 13, U.sub(), false));
        r.addView(t, U.lpw(1));
        FrameLayout arrow = new FrameLayout(a);
        arrow.setBackground(U.oval(U.dark ? 0xFF2D313B : 0xFFF1F2F4));
        arrow.addView(U.icon(a, R.drawable.ic_chevron, U.text(), 22),
                new FrameLayout.LayoutParams(U.dp(a, 22), U.dp(a, 22), Gravity.CENTER));
        r.addView(arrow, U.lpm(a, 40, 40, 8, 0, 0, 0));
        return r;
    }

    static void labDialog(final Activity a, final Runnable refresh) {
        LinearLayout f = new LinearLayout(a);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(U.dp(a, 20), U.dp(a, 8), U.dp(a, 20), 0);
        final EditText n = field(a, f, "Lab name", Prefs.labName(a), U.T_TEXT);
        final EditText ad = field(a, f, "Address (printed on report)", Prefs.labAddress(a), U.T_TEXT);
        final EditText ph = field(a, f, "Lab phone (printed on report)", Prefs.labPhone(a), U.T_PHONE);
        final EditText su = field(a, f, "Support number", Prefs.support(a), U.T_PHONE);
        ScrollView sv = new ScrollView(a);
        sv.addView(f);
        new AlertDialog.Builder(a).setTitle("Lab Details").setView(sv)
                .setPositiveButton("Save", (d, w) -> {
                    String name = n.getText().toString().trim();
                    if (!name.isEmpty()) Prefs.put(a, "lab_name", name);
                    Prefs.put(a, "lab_address", ad.getText().toString().trim());
                    Prefs.put(a, "lab_phone", ph.getText().toString().trim());
                    Prefs.put(a, "support", su.getText().toString().trim());
                    refresh.run();
                })
                .setNegativeButton("Cancel", null).show();
    }

    private static EditText field(Activity a, LinearLayout parent, String hint, String val, int type) {
        EditText e = new EditText(a);
        e.setHint(hint);
        e.setInputType(type);
        e.setText(val);
        parent.addView(e, U.lp(-1, -2));
        return e;
    }

    private static void security(final Activity a) {
        if (Prefs.pin(a).isEmpty()) {
            U.prompt(a, "Set PIN lock (4+ digits)", "PIN", "", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD, s -> {
                if (s.length() < 4) {
                    U.toast(a, "PIN must be at least 4 digits");
                    return;
                }
                Prefs.put(a, "pin", s);
                U.toast(a, "PIN lock is ON");
            });
        } else {
            new AlertDialog.Builder(a).setTitle("PIN lock is ON")
                    .setPositiveButton("Turn off", (d, w) -> U.prompt(a, "Enter current PIN", "PIN", "",
                            InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD, s -> {
                                if (s.equals(Prefs.pin(a))) {
                                    Prefs.put(a, "pin", "");
                                    U.toast(a, "PIN lock is OFF");
                                } else {
                                    U.toast(a, "Wrong PIN");
                                }
                            }))
                    .setNegativeButton("Close", null).show();
        }
    }

    private static void changePin(final Activity a) {
        final int type = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD;
        final Runnable setNew = () -> U.prompt(a, "New PIN (4+ digits)", "PIN", "", type, s -> {
            if (s.length() < 4) {
                U.toast(a, "PIN must be at least 4 digits");
                return;
            }
            Prefs.put(a, "pin", s);
            U.toast(a, "PIN changed");
        });
        if (Prefs.pin(a).isEmpty()) {
            setNew.run();
        } else {
            U.prompt(a, "Enter current PIN", "PIN", "", type, s -> {
                if (s.equals(Prefs.pin(a))) setNew.run();
                else U.toast(a, "Wrong PIN");
            });
        }
    }
}
