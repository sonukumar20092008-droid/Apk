package com.labdesk.app;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Local SQLite storage (offline). */
final class Db extends SQLiteOpenHelper {
    private static Db inst;

    static synchronized Db get(Context c) {
        if (inst == null) inst = new Db(c.getApplicationContext());
        return inst;
    }

    private Db(Context c) { super(c, "labdesk.db", null, 1); }

    @Override
    public void onCreate(SQLiteDatabase d) {
        d.execSQL("CREATE TABLE bookings (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT, title TEXT, name TEXT, "
                + "age INTEGER, age_unit TEXT, gender TEXT, mobile TEXT, department TEXT, doctor TEXT, "
                + "comm_pct REAL, comm_amt REAL, ts INTEGER, items TEXT, total REAL, discount REAL, paid REAL, "
                + "status TEXT, important INTEGER, collected_by TEXT, description TEXT, info TEXT, results TEXT)");
        d.execSQL("CREATE TABLE items (id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, name TEXT, extra TEXT, "
                + "amount REAL, ts INTEGER)");
        seed(d, "department", "Pathology", "", 0);
        seed(d, "test", "CBC", "|", 300);
        seed(d, "test", "Hemoglobin", "g/dL|13.0 - 17.0", 100);
        seed(d, "test", "Blood Sugar Fasting", "mg/dL|70 - 100", 80);
        seed(d, "test", "Lipid Profile", "mg/dL|See report", 600);
        seed(d, "test", "Thyroid TSH", "uIU/mL|0.4 - 4.0", 400);
        seed(d, "test", "Urine Routine", "|", 100);
        seed(d, "package", "Basic Health Checkup", "CBC,Blood Sugar Fasting,Lipid Profile", 899);
        seed(d, "staff", "Lab Staff", "Sample collector", 0);
    }

    @Override
    public void onUpgrade(SQLiteDatabase d, int o, int n) {}

    private static void seed(SQLiteDatabase d, String type, String name, String extra, double amt) {
        Item i = new Item();
        i.type = type;
        i.name = name;
        i.extra = extra;
        i.amount = amt;
        d.insert("items", null, i.cv());
    }

    // ---------- bookings ----------

    long saveBooking(Booking b) {
        SQLiteDatabase d = getWritableDatabase();
        if (b.id == 0) {
            b.id = d.insert("bookings", null, b.cv());
        } else {
            d.update("bookings", b.cv(), "id=?", new String[]{String.valueOf(b.id)});
        }
        return b.id;
    }

    void deleteBooking(long id) {
        getWritableDatabase().delete("bookings", "id=?", new String[]{String.valueOf(id)});
    }

    List<Booking> bookings(String status, long from, long to, String q) {
        StringBuilder w = new StringBuilder("ts>=? AND ts<=?");
        List<String> a = new ArrayList<>();
        a.add(String.valueOf(from));
        a.add(String.valueOf(to));
        if (status != null) {
            w.append(" AND status=?");
            a.add(status);
        }
        if (q != null && !q.trim().isEmpty()) {
            w.append(" AND (name LIKE ? OR mobile LIKE ? OR code LIKE ?)");
            String l = "%" + q.trim() + "%";
            a.add(l);
            a.add(l);
            a.add(l);
        }
        Cursor c = getReadableDatabase().query("bookings", null, w.toString(), a.toArray(new String[0]),
                null, null, "CASE WHEN status='Booked' AND important=1 THEN 0 ELSE 1 END, ts DESC");
        List<Booking> out = new ArrayList<>();
        try {
            while (c.moveToNext()) out.add(Booking.from(c));
        } finally {
            c.close();
        }
        return out;
    }

    /** Same patient (same name + mobile) keeps the same code (P1, P2...). */
    String nextCode(String name, String mobile) {
        SQLiteDatabase d = getReadableDatabase();
        if (mobile != null && !mobile.isEmpty()) {
            Cursor c = d.rawQuery("SELECT code FROM bookings WHERE mobile=? AND LOWER(name)=LOWER(?) LIMIT 1",
                    new String[]{mobile, name});
            try {
                if (c.moveToFirst()) return c.getString(0);
            } finally {
                c.close();
            }
        }
        int max = 0;
        Cursor c = d.rawQuery("SELECT IFNULL(MAX(CAST(SUBSTR(code,2) AS INTEGER)),0) FROM bookings", null);
        try {
            if (c.moveToFirst()) max = c.getInt(0);
        } finally {
            c.close();
        }
        return "P" + (max + 1);
    }

    /** code, name, "age unit (G)", mobile, visits, due */
    List<String[]> patients() {
        List<String[]> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT code, name, age, age_unit, gender, mobile, COUNT(*), "
                        + "SUM(MAX(total-discount-paid,0)) FROM bookings GROUP BY code ORDER BY MAX(ts) DESC", null);
        try {
            while (c.moveToNext()) {
                String g = c.getString(4);
                String gs = g == null || g.isEmpty() ? "" : " (" + g.substring(0, 1) + ")";
                out.add(new String[]{
                        c.getString(0), c.getString(1),
                        c.getInt(2) + " " + c.getString(3) + gs,
                        c.getString(5) == null ? "" : c.getString(5),
                        String.valueOf(c.getInt(6)),
                        String.valueOf(c.getDouble(7))});
            }
        } finally {
            c.close();
        }
        return out;
    }

    // ---------- report rows ----------

    /** Returns rows: {name, result, unit, ref, price, kind} where kind is "H" (package header) or "T" (test). */
    List<String[]> reportRows(Booking b) {
        Map<String, String> res = b.resultMap();
        List<String[]> rows = new ArrayList<>();
        for (String[] l : b.itemLines()) {
            String name = l[0], price = l[1], type = l[2];
            if ("package".equals(type)) {
                rows.add(new String[]{name, "", "", "", price, "H"});
                Item pk = itemByName("package", name);
                if (pk != null && pk.extra != null) {
                    for (String t : pk.extra.split(",")) {
                        t = t.trim();
                        if (!t.isEmpty()) rows.add(testRow(t, "", res));
                    }
                }
            } else {
                rows.add(testRow(name, price, res));
            }
        }
        return rows;
    }

    private String[] testRow(String name, String price, Map<String, String> res) {
        Item it = itemByName("test", name);
        String unit = "", ref = "";
        if (it != null && it.extra != null) {
            String[] p = it.extra.split("\\|", -1);
            unit = p[0];
            if (p.length > 1) ref = p[1];
        }
        String r = res.get(name);
        return new String[]{name, r == null ? "" : r, unit, ref, price, "T"};
    }

    // ---------- items ----------

    List<Item> items(String type) {
        String order = ("expense".equals(type) || "wallet".equals(type)) ? "ts DESC" : "name COLLATE NOCASE";
        Cursor c = getReadableDatabase().query("items", null, "type=?", new String[]{type}, null, null, order);
        List<Item> out = new ArrayList<>();
        try {
            while (c.moveToNext()) out.add(Item.from(c));
        } finally {
            c.close();
        }
        return out;
    }

    Item itemByName(String type, String name) {
        Cursor c = getReadableDatabase().query("items", null, "type=? AND LOWER(name)=LOWER(?)",
                new String[]{type, name}, null, null, null, "1");
        try {
            if (c.moveToFirst()) return Item.from(c);
        } finally {
            c.close();
        }
        return null;
    }

    long saveItem(Item i) {
        SQLiteDatabase d = getWritableDatabase();
        if (i.id == 0) {
            i.id = d.insert("items", null, i.cv());
        } else {
            d.update("items", i.cv(), "id=?", new String[]{String.valueOf(i.id)});
        }
        return i.id;
    }

    void deleteItem(long id) {
        getWritableDatabase().delete("items", "id=?", new String[]{String.valueOf(id)});
    }

    double sumAmount(String type) { return sumAmountSince(type, 0); }

    double sumAmountSince(String type, long from) {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT IFNULL(SUM(amount),0) FROM items WHERE type=? AND ts>=?",
                new String[]{type, String.valueOf(from)});
        try {
            if (c.moveToFirst()) return c.getDouble(0);
        } finally {
            c.close();
        }
        return 0;
    }
}
