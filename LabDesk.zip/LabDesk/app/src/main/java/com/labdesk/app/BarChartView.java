package com.labdesk.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Simple grouped bar chart: Booked vs Completed per day. */
final class BarChartView extends View {
    private int[] booked = new int[0];
    private int[] completed = new int[0];
    private String[] labels = new String[0];
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    BarChartView(Context c) { super(c); }

    void set(int[] b, int[] c, String[] l) {
        booked = b;
        completed = c;
        labels = l;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        Context c = getContext();
        int w = getWidth(), h = getHeight();
        float left = U.dp(c, 26), top = U.dp(c, 8), bottom = h - U.dp(c, 22), right = w - U.dp(c, 4);
        int n = booked.length;
        int max = 4;
        for (int i = 0; i < n; i++) max = Math.max(max, Math.max(booked[i], completed[i]));

        // grid lines + y labels
        p.setTextSize(U.dp(c, 10));
        for (int g = 0; g <= 4; g++) {
            float y = bottom - (bottom - top) * g / 4f;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(U.dp(c, 1));
            p.setColor(U.line());
            p.setPathEffect(g == 0 ? null : new DashPathEffect(new float[]{U.dp(c, 4), U.dp(c, 4)}, 0));
            cv.drawLine(left, y, right, y, p);
            p.setPathEffect(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(U.sub());
            p.setTextAlign(Paint.Align.RIGHT);
            cv.drawText(String.valueOf(Math.round(max * g / 4f)), left - U.dp(c, 5), y + U.dp(c, 3), p);
        }
        if (n == 0) return;

        float slot = (right - left) / n;
        float barW = Math.min(U.dp(c, 14), slot / 2.6f);
        float radius = barW / 3f;
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < n; i++) {
            float cx = left + slot * i + slot / 2f;
            drawBar(cv, cx - barW - 1, barW, booked[i], max, top, bottom, U.PRIMARY, radius);
            drawBar(cv, cx + 1, barW, completed[i], max, top, bottom, U.GREEN, radius);
            boolean show = n <= 10 || i % 5 == 0 || i == n - 1;
            if (show && i < labels.length) {
                p.setColor(U.sub());
                p.setTextAlign(Paint.Align.CENTER);
                cv.drawText(labels[i], cx, h - U.dp(c, 6), p);
            }
        }
    }

    private void drawBar(Canvas cv, float x, float w, int v, int max, float top, float bottom, int color, float r) {
        if (v <= 0) return;
        float hgt = (bottom - top) * v / (float) max;
        p.setColor(color);
        cv.drawRoundRect(new RectF(x, bottom - hgt, x + w, bottom), r, r, p);
    }
}
