package com.labdesk.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.view.Menu;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;

import androidx.core.content.FileProvider;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Actions on a booking: results, payment, PDF sharing, delete. */
final class Actions {
    private Actions() {}

    static void menu(final Activity a, View anchor, final Booking b, final Runnable refresh) {
        PopupMenu m = new PopupMenu(a, anchor);
        Menu mm = m.getMenu();
        if (b.completed()) {
            mm.add(0, 2, 0, "Share PDF report");
            mm.add(0, 3, 0, "Send on WhatsApp");
            mm.add(0, 4, 0, "Edit results");
            mm.add(0, 5, 0, "Move back to Bookings");
        } else {
            mm.add(0, 1, 0, "Enter results & complete");
        }
        if (b.due() > 0) mm.add(0, 6, 0, "Collect payment (" + U.money(b.due()) + ")");
        mm.add(0, 7, 0, "Delete");
        m.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 1:
                case 4:
                    enterResults(a, b, refresh);
                    break;
                case 2:
                    share(a, b, false);
                    break;
                case 3:
                    share(a, b, true);
                    break;
                case 5:
                    b.status = "Booked";
                    Db.get(a).saveBooking(b);
                    refresh.run();
                    break;
                case 6:
                    collect(a, b, refresh);
                    break;
                case 7:
                    confirmDelete(a, b, refresh);
                    break;
                default:
                    break;
            }
            return true;
        });
        m.show();
    }

    private static void collect(final Activity a, final Booking b, final Runnable refresh) {
        U.prompt(a, "Collect payment", "Amount", String.valueOf((long) Math.ceil(b.due())), U.T_NUM, s -> {
            double v = U.num(s);
            if (v <= 0) return;
            b.paid += v;
            Db.get(a).saveBooking(b);
            refresh.run();
        });
    }

    private static void confirmDelete(final Activity a, final Booking b, final Runnable refresh) {
        new AlertDialog.Builder(a)
                .setTitle("Delete booking?")
                .setMessage(b.name + " (" + b.code + ") will be removed permanently.")
                .setPositiveButton("Delete", (d, w) -> {
                    Db.get(a).deleteBooking(b.id);
                    refresh.run();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** One input per test; saving marks the booking as Completed. */
    static void enterResults(final Activity a, final Booking b, final Runnable refresh) {
        final Map<String, EditText> fields = new LinkedHashMap<>();
        Map<String, String> old = b.resultMap();
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(U.dp(a, 18), U.dp(a, 8), U.dp(a, 18), U.dp(a, 8));
        List<String[]> rows = Db.get(a).reportRows(b);
        for (String[] r : rows) {
            if ("H".equals(r[5])) {
                col.addView(U.tv(a, r[0], 14, 0xFF111111, true), U.lpm(a, -2, -2, 0, 10, 0, 0));
                continue;
            }
            if (fields.containsKey(r[0])) continue;
            String label = r[0];
            if (!r[2].isEmpty()) label += " (" + r[2] + ")";
            if (!r[3].isEmpty()) label += "   ref: " + r[3];
            col.addView(U.tv(a, label, 12, 0xFF555555, false), U.lpm(a, -2, -2, 0, 8, 0, 0));
            EditText e = new EditText(a);
            e.setSingleLine(true);
            e.setHint("Result");
            String o = old.get(r[0]);
            if (o != null) e.setText(o);
            col.addView(e, U.lp(-1, -2));
            fields.put(r[0], e);
        }
        ScrollView sv = new ScrollView(a);
        sv.addView(col);
        new AlertDialog.Builder(a)
                .setTitle("Results - " + b.name)
                .setView(sv)
                .setPositiveButton("Save & Complete", (d, w) -> {
                    StringBuilder sb = new StringBuilder();
                    for (Map.Entry<String, EditText> en : fields.entrySet()) {
                        String v = en.getValue().getText().toString().trim();
                        if (!v.isEmpty()) sb.append(en.getKey()).append('\t').append(v).append('\n');
                    }
                    b.results = sb.toString();
                    b.status = "Completed";
                    Db.get(a).saveBooking(b);
                    U.toast(a, "Report completed");
                    refresh.run();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Asks whether to hide the price list for this PDF (default = Settings option), then shares it. */
    static void share(final Activity a, final Booking b, final boolean whatsapp) {
        final CheckBox cb = new CheckBox(a);
        cb.setText("Hide price list on patient report");
        cb.setChecked(Prefs.hidePrice(a));
        LinearLayout f = new LinearLayout(a);
        f.setPadding(U.dp(a, 22), U.dp(a, 12), U.dp(a, 22), 0);
        f.addView(cb);
        new AlertDialog.Builder(a)
                .setTitle("Share report")
                .setView(f)
                .setPositiveButton("Share", (d, w) -> {
                    try {
                        File file = PdfHelper.build(a, b, cb.isChecked());
                        send(a, b, file, whatsapp);
                    } catch (Exception e) {
                        U.toast(a, "Could not create PDF: " + e.getMessage());
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private static void send(Activity a, Booking b, File file, boolean whatsapp) {
        Uri uri = FileProvider.getUriForFile(a, a.getPackageName() + ".fileprovider", file);
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("application/pdf");
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.putExtra(Intent.EXTRA_TEXT, "Report for " + b.name + " - " + Prefs.labName(a));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (whatsapp) {
            String digits = b.mobile.replaceAll("[^0-9]", "");
            if (digits.length() == 10) digits = "91" + digits;
            if (digits.length() >= 11) i.putExtra("jid", digits + "@s.whatsapp.net");
            String[] pkgs = {"com.whatsapp", "com.whatsapp.w4b"};
            for (String pkg : pkgs) {
                try {
                    i.setPackage(pkg);
                    a.startActivity(i);
                    return;
                } catch (ActivityNotFoundException ignored) {
                    // try next package
                }
            }
            i.setPackage(null);
            i.removeExtra("jid");
            U.toast(a, "WhatsApp not found, choose another app");
        }
        a.startActivity(Intent.createChooser(i, "Share report"));
    }

    /** Names of tests/packages with price, for pick dialogs. */
    static List<String> labels(List<Item> items) {
        List<String> l = new ArrayList<>();
        for (Item it : items) l.add(it.name + "  -  " + U.money(it.amount));
        return l;
    }
}
