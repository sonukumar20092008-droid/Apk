package com.labdesk.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

public class MainActivity extends AppCompatActivity {

    private static final String[][] MENU = {
            {"#DASHBOARD & ANALYTICS"},
            {"Dashboard", "dash"},
            {"#BOOKING & REPORTS"},
            {"Booking & Reports", "bookings"},
            {"Collection Center", "center"},
            {"Patients", "patients"},
            {"Shortcut Keys", "shortcuts"},
            {"#LAB INFO & TESTS"},
            {"Manage Pathology", "department"},
            {"Collection Centers", "center"},
            {"Lab Test & Packages", "testpkg"},
            {"NABL & Quality", "nabl"},
            {"#REFERRALS & OUTSOURCING"},
            {"Manage Referrals", "doctor"},
            {"Manage Outsource Labs", "outsource"},
            {"Manage Insource Labs", "insource"},
            {"#ACCOUNTING & EXPENSES"},
            {"Finance & Expenses", "expense"},
            {"Staff & Referral Accounts", "account"},
            {"Wallet Management", "wallet"},
            {"#INVENTORY MANAGEMENT"},
            {"Inventory", "inventory"},
            {"#USER & ACCESS"},
            {"Manage Users", "user"},
            {"Manage Roles", "role"},
            {"#STAFF & PAYROLL"},
            {"Manage Staff", "staff"},
            {"#BUSINESS INSIGHTS"},
            {"Report", "summary"},
            {"#ADDONS & SUBSCRIPTIONS"},
            {"Manage Subscriptions", "server"},
            {"Snap2Report", "server"},
            {"AI Interpretation", "server"},
            {"Refer & Earn", "refer"},
    };

    private DrawerLayout drawer;
    private LinearLayout header, menuList;
    private FrameLayout body;
    private final View[] tabChips = new View[4];
    private final android.widget.ImageView[] tabIcons = new android.widget.ImageView[4];
    private int tab = 0;
    private String query = "";
    private boolean built = false;

    private final Runnable refreshR = () -> showTab(tab);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        U.init(this);
        U.style(this);
        if (Prefs.pin(this).isEmpty()) {
            build();
        } else {
            setContentView(new View(this));
            askPin();
        }
    }

    private void askPin() {
        final EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setHint("PIN");
        FrameLayout f = new FrameLayout(this);
        f.setPadding(U.dp(this, 20), U.dp(this, 8), U.dp(this, 20), 0);
        f.addView(e);
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle(Prefs.labName(this) + " - Enter PIN")
                .setView(f)
                .setCancelable(false)
                .setPositiveButton("Unlock", null)
                .setNegativeButton("Exit", (x, w) -> finish())
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (e.getText().toString().equals(Prefs.pin(this))) {
                d.dismiss();
                build();
            } else {
                U.toast(this, "Wrong PIN");
                e.setText("");
            }
        }));
        d.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (built) showTab(tab);
    }

    // ------------------------------------------------------------------ layout

    private void build() {
        built = true;
        drawer = new DrawerLayout(this);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setBackgroundColor(U.bg());

        header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(U.dp(this, 10), U.dp(this, 8), U.dp(this, 14), U.dp(this, 8));
        main.addView(header, U.lp(-1, -2));

        body = new FrameLayout(this);
        main.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
        main.addView(bottomBar(), U.lp(-1, U.dp(this, 86)));

        drawer.addView(main, new DrawerLayout.LayoutParams(-1, -1));

        ScrollView ds = new ScrollView(this);
        ds.setBackgroundColor(U.bg());
        LinearLayout dc = new LinearLayout(this);
        dc.setOrientation(LinearLayout.VERTICAL);
        dc.setPadding(U.dp(this, 14), U.dp(this, 16), U.dp(this, 14), U.dp(this, 20));
        EditText search = U.et(this, "Search menu", InputType.TYPE_CLASS_TEXT);
        dc.addView(search, U.lpm(this, -1, -2, 0, 0, 0, 8));
        menuList = new LinearLayout(this);
        menuList.setOrientation(LinearLayout.VERTICAL);
        dc.addView(menuList, U.lp(-1, -2));
        TextView ver = U.tv(this, "LabDesk  ·  Version 1.0", 12, U.sub(), false);
        ver.setGravity(Gravity.CENTER);
        dc.addView(ver, U.lpm(this, -1, -2, 0, 24, 0, 0));
        ds.addView(dc);
        DrawerLayout.LayoutParams dlp = new DrawerLayout.LayoutParams(U.dp(this, 300), -1);
        dlp.gravity = GravityCompat.START;
        drawer.addView(ds, dlp);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable s) { buildMenu(s.toString()); }
        });
        buildMenu("");

        setContentView(drawer);
        showTab(0);
    }

    private View bottomBar() {
        FrameLayout wrap = new FrameLayout(this);
        wrap.setBackgroundColor(U.bg());

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        float r = U.dp(this, 26);
        GradientDrawable g = new GradientDrawable();
        g.setColor(U.card());
        g.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        bar.setBackground(g);
        bar.setElevation(U.dp(this, 6));
        int[] icons = {R.drawable.ic_dashboard, R.drawable.ic_calendar, R.drawable.ic_reports, R.drawable.ic_settings};
        for (int i = 0; i < 4; i++) {
            if (i == 2) bar.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1.1f));
            FrameLayout cell = new FrameLayout(this);
            LinearLayout chip = new LinearLayout(this);
            chip.setGravity(Gravity.CENTER);
            android.widget.ImageView ic = U.icon(this, icons[i], U.sub(), 26);
            chip.addView(ic);
            cell.addView(chip, new FrameLayout.LayoutParams(U.dp(this, 56), U.dp(this, 44), Gravity.CENTER));
            tabChips[i] = chip;
            tabIcons[i] = ic;
            final int idx = i;
            cell.setOnClickListener(v -> showTab(idx));
            bar.addView(cell, new LinearLayout.LayoutParams(0, U.dp(this, 62), 1f));
        }
        wrap.addView(bar, new FrameLayout.LayoutParams(-1, U.dp(this, 62), Gravity.BOTTOM));

        FrameLayout fab = new FrameLayout(this);
        fab.setBackground(U.oval(U.PRIMARY));
        fab.setElevation(U.dp(this, 8));
        fab.addView(U.icon(this, R.drawable.ic_add, Color.WHITE, 30),
                new FrameLayout.LayoutParams(U.dp(this, 30), U.dp(this, 30), Gravity.CENTER));
        fab.setOnClickListener(v -> startActivity(new Intent(this, NewBookingActivity.class)));
        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(U.dp(this, 60), U.dp(this, 60),
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        flp.topMargin = U.dp(this, 2);
        wrap.addView(fab, flp);
        wrap.setLayoutParams(new LinearLayout.LayoutParams(-1, U.dp(this, 86)));
        return wrap;
    }

    private void updateBar() {
        for (int i = 0; i < 4; i++) {
            boolean on = i == tab;
            tabChips[i].setBackground(on ? U.rect(this, U.chip(), 18) : null);
            tabIcons[i].setColorFilter(on ? U.chipText() : U.sub(), android.graphics.PorterDuff.Mode.SRC_IN);
        }
    }

    // ------------------------------------------------------------------ tabs

    void showTab(int t) {
        if (!built) return;
        tab = t;
        header(t);
        View v;
        switch (t) {
            case 0:
                v = Screens.dashboard(this, refreshR);
                break;
            case 1:
                v = Screens.bookingList(this, "Booked", query, refreshR);
                break;
            case 2:
                v = Screens.bookingList(this, "Completed", query, refreshR);
                break;
            default:
                v = Screens.settings(this, refreshR);
                break;
        }
        body.removeAllViews();
        body.addView(v, new FrameLayout.LayoutParams(-1, -1));
        updateBar();
    }

    private void header(int t) {
        header.removeAllViews();
        FrameLayout menu = U.circleBtn(this, R.drawable.ic_menu);
        menu.setOnClickListener(v -> drawer.openDrawer(GravityCompat.START));
        header.addView(menu, U.lpm(this, 44, 44, 0, 0, 10, 0));

        if (t == 0) {
            LinearLayout chip = new LinearLayout(this);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setBackground(U.rect(this, U.card(), 14, U.line()));
            chip.setPadding(U.dp(this, 10), U.dp(this, 10), U.dp(this, 10), U.dp(this, 10));
            TextView ck = U.tv(this, "✓", 13, Color.WHITE, true);
            ck.setGravity(Gravity.CENTER);
            ck.setBackground(U.oval(U.GREEN));
            chip.addView(ck, new LinearLayout.LayoutParams(U.dp(this, 24), U.dp(this, 24)));
            TextView nm = U.tv(this, Prefs.labName(this), 15, U.text(), true);
            nm.setSingleLine(true);
            nm.setEllipsize(TextUtils.TruncateAt.END);
            nm.setPadding(U.dp(this, 10), 0, U.dp(this, 6), 0);
            chip.addView(nm, U.lpw(1));
            chip.addView(U.icon(this, R.drawable.ic_expand, U.sub(), 22));
            chip.setOnClickListener(v -> Screens.labDialog(this, refreshR));
            header.addView(chip, U.lpmw(this, 1, 0, 0, 10, 0));
        } else {
            LinearLayout tt = new LinearLayout(this);
            tt.setOrientation(LinearLayout.VERTICAL);
            String[] titles = {"", "Bookings", "Reports", "Settings"};
            String[] subs = {"", "Samples booked, waiting for results", "Quickly find and manage patient reports",
                    "Adjust preferences to match your lab's workflow"};
            tt.addView(U.tv(this, titles[t], 20, U.text(), true));
            String sub = query.isEmpty() || t == 3 ? subs[t] : "Search: " + query;
            TextView st = U.tv(this, sub, 12, U.sub(), false);
            st.setSingleLine(true);
            st.setEllipsize(TextUtils.TruncateAt.END);
            tt.addView(st);
            header.addView(tt, U.lpmw(this, 1, 0, 0, 8, 0));
            if (t == 1 || t == 2) {
                FrameLayout s = U.circleBtn(this, R.drawable.ic_search);
                s.setOnClickListener(v -> U.prompt(this, "Search patient", "Name, mobile or patient ID", query,
                        InputType.TYPE_CLASS_TEXT, q -> {
                            query = q;
                            showTab(tab);
                        }));
                header.addView(s, U.lpm(this, 44, 44, 0, 0, 8, 0));
            }
        }
        FrameLayout p = U.circleBtn(this, R.drawable.ic_person);
        p.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle(Prefs.labName(this))
                .setMessage("Offline lab desk – all data is stored on this phone.")
                .setPositiveButton("Edit lab details", (d, w) -> Screens.labDialog(this, refreshR))
                .setNegativeButton("Close", null).show());
        header.addView(p);
    }

    // ------------------------------------------------------------------ drawer menu

    private void buildMenu(String filter) {
        menuList.removeAllViews();
        String f = filter.trim().toLowerCase();
        String pendingSection = null;
        for (String[] m : MENU) {
            if (m[0].startsWith("#")) {
                pendingSection = m[0].substring(1);
                continue;
            }
            if (!f.isEmpty() && !m[0].toLowerCase().contains(f)) continue;
            if (pendingSection != null) {
                TextView sec = U.tv(this, pendingSection, 11, U.sub(), true);
                sec.setLetterSpacing(0.1f);
                menuList.addView(sec, U.lpm(this, -2, -2, 4, 16, 0, 6));
                pendingSection = null;
            }
            menuList.addView(menuRow(m[0], m[1]), U.lpm(this, -1, -2, 0, 0, 0, 8));
        }
    }

    private View menuRow(String title, final String key) {
        LinearLayout r = U.card(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        int ic = R.drawable.ic_folder;
        if (key.equals("dash")) ic = R.drawable.ic_dashboard;
        else if (key.equals("bookings")) ic = R.drawable.ic_calendar;
        else if (key.equals("wallet")) ic = R.drawable.ic_wallet;
        else if (key.equals("summary")) ic = R.drawable.ic_reports;
        else if (key.equals("patients")) ic = R.drawable.ic_person;
        FrameLayout c = new FrameLayout(this);
        c.setBackground(U.rect(this, key.equals("dash") ? U.PRIMARY : U.chip(), 12));
        c.addView(U.icon(this, ic, key.equals("dash") ? Color.WHITE : U.chipText(), 22),
                new FrameLayout.LayoutParams(U.dp(this, 22), U.dp(this, 22), Gravity.CENTER));
        r.addView(c, U.lpm(this, 40, 40, 0, 0, 12, 0));
        r.addView(U.tv(this, title, 15, U.text(), true), U.lpw(1));
        r.addView(U.icon(this, R.drawable.ic_chevron, U.sub(), 20));
        r.setPadding(U.dp(this, 10), U.dp(this, 10), U.dp(this, 10), U.dp(this, 10));
        r.setOnClickListener(v -> {
            drawer.closeDrawers();
            open(key);
        });
        return r;
    }

    private void open(String key) {
        switch (key) {
            case "dash":
                showTab(0);
                break;
            case "bookings":
                showTab(1);
                break;
            case "shortcuts":
                shortcuts();
                break;
            case "testpkg":
                new AlertDialog.Builder(this).setTitle("Lab Test & Packages")
                        .setItems(new String[]{"Tests", "Packages"},
                                (d, w) -> ItemsActivity.open(this, w == 0 ? "test" : "package"))
                        .show();
                break;
            case "summary":
                startActivity(new Intent(this, SummaryActivity.class));
                break;
            case "server":
                U.info(this, "Online feature",
                        "This feature needs an online server (accounts, payments, cloud), so it is not part of this offline version.");
                break;
            case "refer":
                shareApp();
                break;
            default:
                ItemsActivity.open(this, key);
                break;
        }
    }

    private void shortcuts() {
        final String[] names = {"New booking", "Today's bookings", "Today's reports", "Add test", "Add expense", "Patients"};
        new AlertDialog.Builder(this).setTitle("Shortcut Keys").setItems(names, (d, w) -> {
            switch (w) {
                case 0:
                    startActivity(new Intent(this, NewBookingActivity.class));
                    break;
                case 1:
                    Screens.range = 0;
                    showTab(1);
                    break;
                case 2:
                    Screens.range = 0;
                    showTab(2);
                    break;
                case 3:
                    ItemsActivity.open(this, "test");
                    break;
                case 4:
                    ItemsActivity.open(this, "expense");
                    break;
                default:
                    ItemsActivity.open(this, "patients");
                    break;
            }
        }).show();
    }

    void shareApp() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, "Try LabDesk - a simple app for diagnostic labs to manage bookings and reports.");
        startActivity(Intent.createChooser(i, "Share app"));
    }

    @Override
    public void onBackPressed() {
        if (drawer != null && drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawers();
        } else if (built && tab != 0) {
            showTab(0);
        } else {
            super.onBackPressed();
        }
    }
}
